$(document).ready(function(){
  $('#loginform').validate({
    rules: {
      email: {
		email:true,  
        required: true
      },
      password: {
        required: true
      },
    },
    highlight: function(element) {
      $(element).closest('.form-group').removeClass('has-success').addClass('has-error')
      $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
    },
    unhighlight: function(element) {
      $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
    }
  });

  $('#loginform').formAnimation({ animatedClass: 'shake' });

   $('#signupform').validate({
    rules: {
      company: {
		required: true,
		minlength: 3
		
	},
	 email:{
	    required: true,
	    email:true	
	},
	  password:{
		required: true,
		minlength: 6
	},
	 c_password:{
		equalTo : "#password"
	},
    },
    highlight: function(element) {
      $(element).closest('.form-group').removeClass('has-success').addClass('has-error')
      $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
    },
    unhighlight: function(element) {
      $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
    }
  });
  
  $('#signupform').formAnimation({ animatedClass: 'shake' });

$('#loc_record').validate({
    rules: {
    msa_name: {
		required: true,
	},
	 latitude: {
		required: true,
	},
	 longitude: {
		required: true,
	},
	 b_category: {
		required: true,
	},
	 b_id: {
		required: true,
	},
	 c_office: {
		required: true,
	},
	 f_status: {
		required: true,
	},
	 f_ownership: {
		required: true,
	},
	 c_type: {
		required: true,
	}, 
	a_medium: {
		required: true,
	},
    npanxx: {
		required: true,
	},
	lata: {
		required: true,
	},
	b_a_a: {
		required: true,
	},
	date: {
		required: true,
	},
	cost: {
		required: true,
	},
	fiber_contractor: {
		required: true,
	},
	lat_distance: {
		required: true,
	},
	lat_cost: {
		required: true,
	},
	lat_count: {
		required: true,
	},
	},
    highlight: function(element) {
      $(element).closest('.form-group').removeClass('has-success').addClass('has-error')
      $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
    },
    unhighlight: function(element) {
      $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
    }
  });
  
  $('#loc_record').formAnimation({ animatedClass: 'shake' });
$('#contact_from').validate({
    rules: {
      title: {
		required: true,
		minlength: 6,
		maxlength: 10
	},
	 email:{
	    required: true,
	    email:true	
	},
	  c_name:{
		required: true,
		minlength: 3,
		maxlength: 10
	},
	 phone:{
		required: true,
		custom_number: true,
		minlength: 12,
		maxlength:12
		
	},
	 landline:{
		required: true,
		custom_number: true,
		minlength: 12,
		maxlength:12
	},
    },
    highlight: function(element) {
      $(element).closest('.form-group').removeClass('has-success').addClass('has-error')
      $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
    },
    unhighlight: function(element) {
      $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
    }
  });
  
  $('#contact_from').formAnimation({ animatedClass: 'shake' });

 $.validator.addMethod("custom_number", function(value, element) {
    return this.optional(element) || value === "NA" ||
        value.match(/^[0-9,\+-]+$/);
}, "Enter Only Numbers ?");

});


 




 


