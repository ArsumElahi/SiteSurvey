<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
 
  if(!isset($session_data[0]['user_id']))
  {
     redirect(base_url()."Login/index");
  
  }
 if($session_data[0]['user_type']=="3"){
   redirect(base_url()."Login/home");
  }
?>

<!DOCTYPE html>
<html>
<head>
<title>Survey - Support</title>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>



<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.1/modernizr.min.js'></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">

<script src="<?php echo base_url(); ?>static/js/code.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(3000).slideUp('slow');
  
}
</script>
</head>
<body onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
           
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">Support</h2>
                                            <h2 id="Note">
                                              
												 <?php 
                                                 if($this->session->flashdata('Err')){
                                                 ?>
                                                 <div class="custom_alert_error alert" id="myAlert" 
                                                 style="display:none;font-size:0.654em;">
                                                 <strong>Error ! </strong> <?=$this->session->flashdata('Err')?>
                                                 </div>
                                                <?php
                                                }
                                                else if($this->session->flashdata('Succ')){
                                                ?>
                                                <div class="custom_alert_success alert" id="myAlert" 
                                                style="display:none;font-size:0.654em;">
                                                <strong>Successfully ! </strong> <?=$this->session->flashdata('Succ')?>
                                               </div>
                                               <?php
                                               }
                                               ?>

                                            </h2>
                                            <div class="form">
                                            <form class="cmxform" id="support_form" class="support_form" method="post" 
                                            action="<?php echo base_url(); ?>Support/createTicket">
                                            
                                            <div class="form-group has-feedback">
                                             <textarea name="ContactComment" id="ContactComment" class="form_textarea radius4
                                              textarea required" rows="" cols="" style="resize:none" required></textarea>
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                            
                                               <input type="submit" name="submitPicture" 
                                               style="background-color:#29AAE3;font-size:24px;margin: 0 0 15px 0;padding: 5px 3%;"
                                                id="submitPicture"
                                               class=" custom_form_submit radius8" value="Open Ticket"  />
                                             
                                        
                                            </form>
                                             <br><br>
                                            <label>Chat with the Help Desk Agent </label>
                                             <br><br>
                                             <h2>Contact us now:</h2>    
                                            <a href="tel:508 202 1807" class="call_button radius8">508-202-1807</a>
                                            
                                            </div>
 											<br>	
                                            <table class="table_styling responsive_table" border="1" style="width:100%;color:	
                                             #FFF; border:1px #FFFFFF solid;text-align:center">
                                            <tr style="background-color:#59A5DF;border-bottom:#353535">
                                              <td style="margin-top:10%">Sr #. </td>
                                              <td>Ticket No</td>
                                              <td>Comment</td>
                                              <td>Response</td>
                                              <td>Status</td>
                                            </tr>
                                          <?php
										   if($this->session->flashdata('Err')==null){
											   $i=0;
												for($j=0;$j<sizeof($result);$j++){
				  							?>
                                             <tr>
                                              <td><?=++$i; ?></td>
                                              <td><?php echo $result[$j]['ticket_no']; ?></td>
                                              <td><?php echo $result[$j]['ticket_desc']; ?></td>
                                              <td><?php echo "No response"; ?></td>
                                              <td><?php echo $result[$j]['ticket_status']; ?></td>
                                            </tr>  
                                        <?php 
									   
									 	}
										   }
										?>     
                                         </table>
                                            
                                        <br><br><br>  
                                        
                                         
                                 
                                       
                                       
                                        <!--End of page container-->
         </div>
       <div class="scrolltop radius20"><a onClick="jQuery('html, body').animate( { scrollTop: 0 }, 'slow' );" 
        href="javascript:void(0);">
       <img src="<?php echo base_url(); ?>static/images/icons/top.png" alt="Go on top" title="Go on top" /></a> 
        
   </div>    
    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>

</body>
</html>