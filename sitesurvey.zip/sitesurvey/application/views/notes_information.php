<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
  $permission_data = $this->session->userdata('permission'); 
  if(!isset($session_data[0]['user_id']))
  {
     redirect(base_url()."Login/index");
  
  }
  if($session_data[0]['user_type']=="3"){
   redirect(base_url()."Login/home");
  }
  
  if(empty($building_data[0]['building_id'])){
	   redirect(base_url()."Login/error");
  }
  $edit=0;
   for($j=0;$j<sizeof($permission_data);$j++){
		if($building_data[0]['building_id']==$permission_data[$j]['building_id']){
			if($permission_data[$j]['permission_type']=="2"){
			   $edit =1;
			}
		}
  }
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<title>Survey - Notes</title>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>
 <script src="<?php echo base_url(); ?>static/js/code.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script type="text/javascript">
  function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
  }
  function clickSubmit(){
		document.forms['notes_form'].submit();
  }
</script>
<head>

</head>

</head>
<body onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">
                                          <div class="page_title_heading_left">
                                           Notes
                                          </div>
                                          <div class="page_title_heading_right">
                                             <div class="page_title_heading_right_1">
                                               <label> Building Address </label>
                                             </div>
                                              <div class="page_title_heading_right_2">
                                                <label><?=$building_data[0]['ss_address']?></label>
                                             </div> 
                                          </div>
                                        </h2>
                                           <br><br>
                                        <h2 id="Note">
                                               <?php 
                                               if($this->session->flashdata('Err')){
                                                ?>
                                               <div class="custom_alert_error alert" id="myAlert" 
                                               style="display:none;font-size:0.654em;">
                                                        <strong>Error ! </strong> <?=$this->session->flashdata('Err')?>
                                              </div>
                                             <?php
											   }
											  else if($this->session->flashdata('Succ')){
										 	 ?>
 											  <div class="custom_alert_success alert" id="myAlert" 
										  	style="display:none;font-size:0.654em;">
										  	    <strong>Successfull ! </strong> <?=$this->session->flashdata('Succ')?>
										     </div>
										   <?php
										     }
                 						   ?>
                                       </h2>   
                                           
                                           <br>
                                            <div class="form">
                                            <form class="cmxform" id="notes_form" class="notes_form" method="post" 
                                            action="<?=base_url();?>Notes/insertNotes">
                                            <label>Notebook:</label>
                                            <div class="form-group has-feedback">
                                             <textarea name="building_notes" id="building_notes" class="form_textarea radius4
                                              textarea required" rows="" cols="" style="resize:none"
                                              <?php    
											  if($session_data[0]['user_type']=="2"){
											   if($edit==1){ ?> 
                                              onBlur="clickSubmit()"
                                              <?php } }
											  else{
											  ?>
                                              onBlur="clickSubmit()"
                                              <?php 
											  }
											  ?> required></textarea>
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                          <input type="submit" id="SubmitNotes" name="SubmitNotes" style="display:none">  
                                        
                                            </form>
                                            <br><Br>
                                           <ul class="posts">
                                             <?php     
											 
											 if($this->session->flashdata('Err')==null){
                                                  foreach($all_list as $notes){
											 ?>	 
										        <li class="post" id="postid1">
                                                     <a href="" class="post_more"><span class="created_by">Created By:</span>
                                                        <span class="created_by_name"><?=$notes['user_name'] ?></span>
                                                      </a>                     
                                                     <div class="post_right_reveal">
                                                     <h4><a href="#">
                                                     <?php echo $notes['note'] ?>
                                                     </a></h4>
                                                     </div>
                                                    <div class="post_left">
                                                        <?php $date_day = date('d',strtotime($notes['date_add']));
														      $date_month = date('M',strtotime($notes['date_add']));
														?>
                                                        
                                                        <span class="day"><?=$date_day?></span>
                                                        <span class="month"><?=$date_month?></span>
                                                    </div>

                                                </li>
                                               		 
                                              <?php
												  }
											 }
                                              ?>   
                                        
                                          </ul>      
                                             <br>
                                            </div>

       <div class="scrolltop radius20"><a onClick="jQuery('html, body').animate( { scrollTop: 0 }, 'slow' );" 
        href="javascript:void(0);">
       <img src="<?php echo base_url(); ?>static/images/icons/top.png" alt="Go on top" title="Go on top" /></a>                                   
                                 
                                       
                                       
                                        <!--End of page container-->
         </div>
         
    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>

 


</body>
</html>