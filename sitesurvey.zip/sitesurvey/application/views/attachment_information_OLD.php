<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $permission_data = $this->session->userdata('permission');  
  $building_data = $this->session->userdata('search_building_result');
  if(!isset($session_data[0]['user_id']))
  {
     redirect(base_url()."Login/index");
  
  }
  if($session_data[0]['user_type']=="3"){
   redirect(base_url()."Login/home");
  }
  
  if(empty($building_data[0]['building_id'])){
	   redirect(base_url()."Login/error");
  }
  $edit=0;
   for($j=0;$j<sizeof($permission_data);$j++){
		if($building_data[0]['building_id']==$permission_data[$j]['building_id']){
			if($permission_data[$j]['permission_type']=="2"){
			   $edit =1;
			}
		}
  }
?>

<!DOCTYPE html>
<html>
<head>
<title>Survey - Attachments</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>static/date_time_plugin/jquery.datetimepicker.css"/ >

<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.1/modernizr.min.js'></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">




<script src="<?php echo base_url(); ?>static/js/code.js"></script>

<script>

function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
 //  $("#myAlert2").slideDown('slow').delay(2000).slideUp('slow');
  
}
function clickSubmit(){
		 var f = document.getElementsByTagName('form')[0];
  if(f.checkValidity()) {
     f.action = "<?php echo base_url(); ?>Attachment/attachedInfo";
	 f.submit();
  } else {
     f.action = "<?php echo base_url(); ?>Attachment/index";
	 f.submit();
  }
}
function clickSubmit2(){
		 var f = document.getElementsByTagName('form')[1];
  if(f.checkValidity()) {
     f.action = "<?php echo base_url(); ?>Attachment/attachedInfo";
	 f.submit();
  } else {
     f.action = "<?php echo base_url(); ?>Attachment/index";
	 f.submit();
  }
}

</script>

</head>
<body onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">
                                          <div class="page_title_heading_left page_title_building"  >
                                           Attachments
                                          </div>
                                          <div class="page_title_heading_right">
                                             <div class="page_title_heading_right_1">
                                               <label> Building Address </label>
                                             </div>
                                              <div class="page_title_heading_right_2">
                                                <label> <?=$building_data[0]['ss_address']?> </label>
                                             </div> 
                                          </div>
                                        </h2>
                                           <br><br>
                                            <h2 id="Note">
										 <?php 
                                         if($this->session->flashdata('Err')){
                                         ?>
                                         <div class="custom_alert_error alert" id="myAlert" 
                                         style="display:none;font-size:0.654em;">
                                         <strong>Error ! </strong> <?=$this->session->flashdata('Err')?>
                                         </div>
                                        <?php
                                        }
                                        else if($this->session->flashdata('Succ')){
                                        ?>
                                        <div class="custom_alert_success alert" id="myAlert" 
                                        style="display:none;font-size:0.654em;">
                                        <strong>Successfully ! </strong> <?=$this->session->flashdata('Succ')?>
                                       </div>
                                       <?php
                                       }
									   
                                       ?>
          							  </h2>
           
                                           <br>
                                            <div class="form">
                                            <form class="cmxform" id="test_form" name="test_form" method="post" 
                                            action="<?php echo base_url(); ?>Attachment/attachedInfo" 
                                            enctype="multipart/form-data">
                                           <fieldset class="scheduler-border" style="max-width:90%;display:inline-block;">
                                            <legend class="scheduler-border">Tests</legend>
                                            <div class="building_records_main">
                                             <div class="building_records_main_left">
                                               <label>Attachment: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="file" name="picture" id="picture" value="" class=
                                             "form_input radius4" required />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                           <div class="building_records_main">
                                             <div class="building_records_main_left">
                                             
                                               <label>Name: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="text" name="p_name" id="p_name" class=
                                             "form_input radius4" required 
                                             value="<?php //if(isset($p_name)){
												 // if($status==1)
												 //echo $p_name;
											 //}
												  ?>"/>
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                               <label>Attached By: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right" >
                                             <input type="text" name="attached_by" id="attached_by" 
                                             value="<?=$session_data[0]['user_name']?>" class=
                                             "form_input radius4" readonly />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                          <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                               <label>Date: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="" name="capture_date" id="capture_date" value="<?php 
											// if(isset($capture_date)){
											//   if($status==1)
											//    if(!empty($capture_date))
											//  echo date('d-M-Y',strtotime($capture_date));
											// }
											 ?>" class=
                                             "form_input radius4" required />
                                             
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                          <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                                 <label>File Link: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="text" name="file_link" id="file_link"  class=
                                             "form_input radius4" required
                                             value="<?php 
											// if(isset($file_link)){
											//   if($status==1)
											//  echo $file_link;
											// }
											 ?>" />
                                            
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                    
                                    
                                         <div class="form-group has-feedback building_records_main_right">
                                            <br>
                                               <div class="building_submit_responsive">
                                               <input type="hidden" name="attachment_category" id="attachment_category"
                                                value="1" />
                                                <?php    
												 if($session_data[0]['user_type']=="2"){
											      if($edit==1){
												?>	  
												 
                                               <input type="submit" name="submitPicture"  id="submitPicture"
                                               class=" custom_form_submit radius4 green 
                                               green_borderbottom" value="Submit"   />
                                               <?php }}
											   else{
											   ?>
                                               <input type="submit" name="submitPicture"  id="submitPicture"
                                               class=" custom_form_submit radius4 green 
                                               green_borderbottom" value="Submit"   />
                                               <?php
											   
											   }
											   ?>
                                              
                                              </div>
                                          </div>    
                                    
                                       </fieldset>    
                                         
                                      </form>
                                       <form class="cmxform" id="other_attachment"  name="other_attachment" method="post" 
                                            action="<?php echo base_url(); ?>Attachment/attachedInfo" 
                                            enctype="multipart/form-data">
                                           <fieldset class="scheduler-border" style="max-width:90%;display:inline-block;">
                                            <legend class="scheduler-border">All Other Attachments</legend>
                                            <div class="building_records_main">
                                             <div class="building_records_main_left">
                                               <label>Attachment: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="file" name="picture" id="picture" value="" class=
                                             "form_input radius4" required />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                           <div class="building_records_main">
                                             <div class="building_records_main_left">
                                             
                                               <label>Name: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="text" name="p_name" id="p_name" class=
                                             "form_input radius4" required 
                                             value="<?php  //if(isset($p_name)){
												// if($status==2)
												// echo $p_name;
												 
										//	 }
												  ?>"/>
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                               <label>Attached By: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right" >
                                             <input type="text" name="attached_by" id="attached_by" 
                                             value="<?=$session_data[0]['user_name']?>" class=
                                             "form_input radius4" readonly />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                          <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                               <label>Date: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="" name="capture_date" id="capture_date1" value="<?php 
											// if(isset($capture_date)){
											 // if($status==2)
											 // if(!empty($capture_date))
											 // echo date('d-M-Y',strtotime($capture_date));
											// }
											 ?>" class=
                                             "form_input radius4" required />
                                             
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                          <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                                 <label>File Link: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="text" name="file_link" id="file_link"  class=
                                             "form_input radius4" required 
                                             value="<?php 
											// if(isset($file_link)){
											//  if($status==2)
											 // echo $file_link;
											// }
											 ?>" />
                                            
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                    
                                    
                                         <div class="form-group has-feedback building_records_main_right">
                                            <br>
                                               <div class="building_submit_responsive">
                                               <input type="hidden" name="attachment_category" id="attachment_category"
                                                value="2" />
                                               <?php    
											   
											    if($session_data[0]['user_type']=="2"){
											      if($edit==1){
											  ?>	    
                                               <input type="submit" name="submitPicture"  id="submitPicture"
                                               class=" custom_form_submit radius4 green 
                                               green_borderbottom" value="Submit"  />
                                              <?php } } 
											  else{
											  ?>
                                              <input type="submit" name="submitPicture"  id="submitPicture"
                                               class=" custom_form_submit radius4 green 
                                               green_borderbottom" value="Submit"  />
                                              <?php
											  }
											  ?>
                                              </div>
                                          </div>    
                                    
                                       </fieldset>    
                                         
                                         
                                           
                                        <br><br><br>
                                      
                                    
                                            
                                      </form>     
                                      
                                      
                                        <br><br><br>
                                      
                                    
                                            
                                      
                                           
                                            <table class="table_styling responsive_table" border="1" style="width:95%;color:	
                                             #FFF; border:1px #FFFFFF solid;text-align:center">
                                            <tr style="background-color:#59A5DF;border-bottom:#353535">
                                              <td style="margin-top:10%">Sr #. </td>
                                              <td>Name</td>
                                              <td>Category</td>
                                              <td>Image</td>
                                              <td>Capture Date</td>
                                            </tr>
                                          <?php
										  
										   if($this->session->flashdata('Err')==null){
											   $i=0;
				 								foreach($all_list as $attachments){
				  							?>
                                             <tr>
                                              <td><?=++$i; ?></td>
                                              <td><?=$attachments['attachment_name'] ?></td>
                                              <td><?php 
											  if($attachments['attachment_category']==1){
											    echo "Tests";
											  }
											  else{
											   echo "All Other Attachments";
											  }
											   ?></td>
                                              <td>
											  <a class="fancybox fancybox.ajax" 
                                               href="<?php echo base_url();?>FancyBox/index?id=<?=$attachments['attachment_path'] 
											   ?>">
                                               <img src="<?=$attachments['attachment_thumbnail'] ?>"  alt="Thumbnail"/>
                                              </a> 
											 </td>
                                              <td><?=date('d-M-Y', strtotime($attachments['capture_date'])); ?></td>
                                              
                                            </tr>  
                                        <?php 
										}
										   }
										?>     
                                         </table>
                                            
                                        <br><br><br>  
                                        
                                          
                                         <br><br>
                                         
                                            
                                            </div>

                                          
                                         
                                 
                                       
                                       
  
                                      <!--End of page container-->
     <br>
     <div class="scrolltop radius20"><a onClick="jQuery('html, body').animate( { scrollTop: 0 }, 'slow' );" 
        href="javascript:void(0);">
       <img src="<?php echo base_url(); ?>static/images/icons/top.png" alt="Go on top" title="Go on top" /></a> 
        
   </div>                                    
         </div>                                        
     
         </div>
    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>static/date_time_plugin/jquery.datetimepicker.full.js"></script>
<script src='<?php echo base_url(); ?>static/js/formAnimation.js'></script>
<script src='<?php echo base_url(); ?>static/js/shake.js'></script>
  
 <script type="text/javascript" src="<?php echo base_url(); ?>static/source/jquery.fancybox.js?v=2.1.5"></script> 
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>static/source/jquery.fancybox.css?v=2.1.5" media="screen" />
  
<script>/*
window.onerror = function(errorMsg) {
	$('#console').html($('#console').html()+'<br>'+errorMsg)
}*/

$('#capture_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});
$('#capture_date1').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$(document).ready(function() {
		$('.fancybox').fancybox();
});
	

</script>

</body>
</html>