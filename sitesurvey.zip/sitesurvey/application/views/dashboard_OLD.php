<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
// print_r($session_data);
 if(!isset($session_data[0]['user_id']))
  {
     redirect(base_url()."Login/index");
  
  }
//echo $insert_building_id;
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<link rel="apple-touch-icon" href="images/apple-touch-icon.png" />
<link rel="apple-touch-startup-image" href="images/apple-touch-startup-image-320x460.png" />
<meta name="author" content="SindevoThemes" />
<meta name="description" content="GoMobile - A next generation web app theme" />
<meta name="keywords" content="mobile web app, mobile template, mobile design, mobile app design, mobile app theme, mobile wordpress theme, my mobile app" />
<title>Survey - Home</title>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>


<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.1/modernizr.min.js'></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>



<link href="http://fabernainggolan.net/demo/multi_autocomplete/assets/jquery/jquery-ui.css" rel="stylesheet">

    <!-- jquery -->
<script src="http://fabernainggolan.net/demo/multi_autocomplete/assets/jquery/jquery.min.js" type="text/javascript"></script>
<script src="http://fabernainggolan.net/demo/multi_autocomplete/assets/jquery/jquery-ui.js" type="text/javascript"></script>
<script>
function initGeolocation()
     {
        if( navigator.geolocation )
        {
           // Call getCurrentPosition with success and failure callbacks
           navigator.geolocation.getCurrentPosition( success, fail );
        }
        else
        {
           alert("Sorry, your browser does not support geolocation services.");
        }
     }

    function success(position){  
	var lat = position.coords.latitude.toString();
	var lng = position.coords.longitude.toString();
	window.location ="<?=base_url();?>Login/searchCurrent?lat="+lat.substring(0,7)+"&lng="+lng.substring(0,7);
	
	}

     function fail() {
        // Could not obtain location
     }
 function getGeolocation()
     {
        if( navigator.geolocation )
        {
           // Call getCurrentPosition with success and failure callbacks
           navigator.geolocation.getCurrentPosition( success1, fail1 );
        }
        else
        {
           alert("Sorry, your browser does not support geolocation services.");
        }
     }

    function success1(position){  
	var lat = position.coords.latitude.toString();
	var lng = position.coords.longitude.toString();
	
	 document.getElementById("n_building_address").value =lat.substring(0,7)+"/"+lng.substring(0,7);
	 document.getElementById("new_building").submit();
	}

     function fail1() {
        // Could not obtain location
     }
	 
	 
function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
}




     $(function () {
        $("#existing_location").autocomplete({    
            minLength:0,
            delay:0,
            source:'<?php echo site_url('Login/searchSuggestion'); ?>',  
            select:function(event, ui){
                $('#existing_id').val(ui.item.id); 
				
				  document.getElementById("dashboard_form").submit();
                }
            });
        });
</script>

<!-- Start of zemtechnologies Zendesk Widget script -->
<script>/*<![CDATA[*/window.zEmbed||function(e,t){var n,o,d,i,s,a=[],r=document.createElement("iframe");window.zEmbed=function(){a.push(arguments)},window.zE=window.zE||window.zEmbed,r.src="javascript:false",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="display: none",d=document.getElementsByTagName("script"),d=d[d.length-1],d.parentNode.insertBefore(r,d),i=r.contentWindow,s=i.document;try{o=s}catch(e){n=document.domain,r.src='javascript:var d=document.open();d.domain="'+n+'";void(0);',o=s}o.open()._l=function(){var o=this.createElement("script");n&&(this.domain=n),o.id="js-iframe-async",o.src=e,this.t=+new Date,this.zendeskHost=t,this.zEQueue=a,this.body.appendChild(o)},o.write('<body onload="document._l();">'),o.close()}("https://assets.zendesk.com/embeddable_framework/main.js","zemtechnologies.zendesk.com");
/*]]>*/</script>
<!-- End of zemtechnologies Zendesk Widget script -->

</head>
<body onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
       
      <div class="sliderbg_menu">
      <div class="pages_container">
      
     <img src="<?php echo base_url(); ?>static/images/icons/logo.png" alt="" title="" 
                                         width="170px" height="100px" style="display:block;margin:0 auto;" />
        <div class="heading">Welcome To Site Survey By Connected2Fiber</div>
      <br>
            <h2 id="Note">
                     <?php 
                     if($this->session->flashdata('Error')){
                     ?>
                     <div class="custom_alert_error alert" id="myAlert" 
                     style="display:none;font-size:0.654em;">
                     <strong>Error ! </strong> <?=$this->session->flashdata('Error')?>
                     </div>
                    <?php
                    }
					else if($this->session->flashdata('Success')){
					?>
                    <div class="custom_alert_success alert" id="myAlert" 
                    style="display:none;font-size:0.654em;">
                    <strong>Successfully ! </strong> <?=$this->session->flashdata('Success')?>
                   </div>
                   <?php
				   }
                   ?>
            </h2>
           
           <div class="form">
                    <form class="cmxform" id="dashboard_form" class="dashboard_form" method="post" 
                    action="<?=base_url();?>Login/searchExistingLocation">
                      <!---   <div class="building_records_main">
                         <div class="building_records_main_left">
                            <label>Pick a Location:</label>
                         </div>  
                         <div class="form-group has-feedback building_records_main_right" >
                           <input type="text" name="pick_location" id="pick_location" class=
                           "form_input radius4"  value=""  />
                           <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                         </div>
                    
                        </div>     
                        ---> 
                         <div  style="width:85%;display:block;margin:0 auto">
                             <div class="dashborad_left">
                                 <label>Search Existing Location:</label>
                              </div>  
                              <div class="form-group has-feedback dashborad_right"  >
                               <div class="dashborad_right_1">
                                <input type="text" name="existing_location" id="existing_location" class=
                                "form_input radius4"  value="<?php if(isset($building_data[0]['building_id'])){
									 echo $building_data[0]['ss_address'];}?>"  required />
                                <input type="hidden" name="existing_id" id="existing_id" />
                              </div> 
                              <div class="dashborad_right_2">
                                  <input type="button" class="custom_form_submit radius4 green" value="Search" 
                                  style="margin-top:5%" onClick="initGeolocation()"></button>
                              </div>
                                 <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                               </div>
                           </div>
                      
                      
                   </form>
                     
                    <form class="cmxform" id="new_building" class="new_building" method="post" 
                    action="<?=base_url();?>Login/insertBuilding">
                         <br><br> 
                         <div style="width:85%;display:block;margin:0 auto">
                              <div class="dashborad_left">
                                 <label>New Building:</label>
                              </div>  
                               <div class="form-group has-feedback dashborad_right">
                               <div class="dashborad_right_1">
                                <input type="text" name="n_building_address" id="n_building_address" class=
                                "form_input radius4"  value="" placeholder="Enter Lat/Long or Address"
                                required  />
                                </div> 
                                <div class="dashborad_right_2"> 
                                  <input type="button" class="custom_form_submit radius4 green" value="Current"
                                  style="margin-top:5%;" onClick="getGeolocation()"></button>
                                </div>
                                 <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                               </div>
                           </div>
                     <br>
                     
                  </form>
                  
                  
                  
                    </div>  
        <br>
        <br>
        <nav id="menu" class="margin_responsive">
        <ul>
           <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
		   echo base_url();?>Support/<?php }?>" title="Support" >
			<li><img src="<?php echo base_url(); ?>static/images/icons/about.png" alt="" title="" /><br>
            <span>Support</span></li></a>
           <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
		   echo base_url();?>Services/<?php }?>" title="Services">
            <li><img src="<?php echo base_url(); ?>static/images/icons/tools.png" alt="" title="" /><br>
            <span>Services</span></li></a>
            <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
			echo base_url();?>Notes/<?php }?>" title="Notes">
            <li><img src="<?php echo base_url(); ?>static/images/icons/blog.png" alt="" title="" /><br>
            <span>Notes</span></li></a>
            <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
			echo base_url();?>Records/<?php }?>" title="Location Records"><li>
            <img src="<?php echo base_url(); ?>static/images/icons/docs.png" alt="" title="" /><br>
            <span>Location Records</span></li></a>
            <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
			echo base_url();?>Pictures/<?php }?>" title="Pictures">
            <li><img src="<?php echo base_url(); ?>static/images/icons/photos.png" alt="" title="" /><br>
            <span>Pictures</span></li></a>
            <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
			echo base_url();?>Videos/<?php }?>" title="Videos">
            <li><img src="<?php echo base_url(); ?>static/images/icons/videos.png" alt="" title="" /><br>
            <span>Videos</span></li></a>
            <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
			echo base_url();?>Building/<?php }?>" title="My Locations">
            <li><img src="<?php echo base_url(); ?>static/images/icons/clients.png" alt="" title="" /><br>
            <span>My Locations</span></li></a>
            <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
			echo base_url();?>Attachment/<?php }?>" title="Attachments">
            <li><img src="<?php echo base_url(); ?>static/images/icons/twitter.png" alt="" title="" /><br>
            <span>Attachments</span></li></a>
            <a href="<?php if(empty($building_data[0]['building_id'])){ echo base_url()."Login/error";} else { 
			echo base_url();?>Contacts/listContacts<?php }?>" title="Building Contacts">
            <li><img src="<?php echo base_url(); ?>static/images/icons/contact.png" alt="" title="" /><br>
            <span>Building Contacts</span></li></a>
            <?php 
			  if($session_data[0]['user_type']=="1"){
			?>
             <a href="<?=base_url(); ?>NewUser/listUser" title="Users">
            <li><img src="<?php echo base_url(); ?>static/images/icons/clients.png" alt="" title="" /><br>
            <span>Users</span></li></a>
          <?php
			  }
		  ?>  
        </ul>
        </nav>
       <div class="clear"></div>  
    </div> 
     </div>
       <div class="scrolltop radius20"><a onClick="jQuery('html, body').animate( { scrollTop: 0 }, 'slow' );" 
        href="javascript:void(0);">
       <img src="<?php echo base_url(); ?>static/images/icons/top.png" alt="Go on top" title="Go on top" /></a> 
        <br>  <br></div>
      </div>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/twitter/jquery.tweet.js" charset="utf-8"></script>


</body>
</html>