<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
 
  if(!isset($session_data[0]['user_id'])){
     redirect(base_url()."Login/index");
  }
  else{
   if($session_data[0]['user_type']!="1"){
	   
	    redirect(base_url()."Login/Home");
   }
   
  }
 if($session_data[0]['user_type']=="3"){
   redirect(base_url()."Login/home");
  }
  
 
?>

<!DOCTYPE html>
<html>
<head>
<title>Survey - New User</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>

<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.1/modernizr.min.js'></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">


<script src="<?php echo base_url(); ?>static/js/code.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<style>
/* Start CSS for Animation*/
form .form-group.has-error label {
color: #F00;}
form .form-group.has-error label.error {
margin-top: 10px;
margin-bottom: 0;
font-weight: 400;
font-size: 15px;}
form .form-group.has-error input, form .form-group.has-error {
border-color: #F00; }
form .form-group.has-error input:focus, form .form-group.has-error textarea:focus {
border-color: #d9534f;
box-shadow: 0 0 6px #d9534f; }
form .form-group.has-success input, form .form-group.has-success textarea {
border-color: #6fd653; }
form .form-group.has-success input:focus, form .form-group.has-success textarea:focus {
border-color: #6fd653;
box-shadow: 0 0 6px #6fd653; }

/* End CSS for Animation */
</style>
<script>

function redirect(url){
   window.location = url;

}

function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
  }
function showingUserPermission(value){
	 var building = document.getElementsByName('building_id[]');
	if(value==1 || value==3){
	 
	   for(var i = 0;i<building.length;i++){
	       //alert("visible_"+building[i]);
	      document.getElementById("visible_"+building[i].value).disabled =true;
		  document.getElementById("edit_"+building[i].value).disabled =true;
		  document.getElementById("edit_"+building[i].value).checked =true;
	   }
	
	}
	else{
	 for(var i = 0;i<building.length;i++){
	       //alert("visible_"+building[i]);
	      document.getElementById("visible_"+building[i].value).disabled =false;
		  document.getElementById("edit_"+building[i].value).disabled =false;
		  document.getElementById("edit_"+building[i].value).checked =false;
	   }
	
	}
}
  
function Visible(edit_id,visible_id){
   if(document.getElementById(visible_id).checked){
     
	    document.getElementById(edit_id).disabled= false;
   }
   else{
     
	    document.getElementById(edit_id).disabled= true;
   }
}
</script>

</head>
<body onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
           
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">
                                          <div class="page_title_heading_left page_title_building"  >
                                           Create User
                                          </div>
                                          <div class="page_title_heading_right">
                                             <div class="page_title_heading_right_1">
                                               <label> Building Address </label>
                                             </div>
                                              <div class="page_title_heading_right_2">
                                                <label> <?=$building_data[0]['ss_address']?> </label>
                                             </div> 
                                          </div>
                                        </h2>
                                           <br><br>
                                             <h2 id="Note">
                                               <?php 
                                                if($this->session->flashdata('Err')){
                                                ?>
                                               <div class="custom_alert_error alert" id="myAlert" 
                                               style="display:none;font-size:0.654em;">
                                                        <strong>Error ! </strong> <?=$this->session->flashdata('Err')?>
                                             </div>
                                             <?php
                                                }
                                                if($this->session->flashdata('Succ')){
                                                ?>
                                              <div class="custom_alert_success alert" id="myAlert" 
                                                style="display:none;font-size:0.654em;">
                                                <strong>Successfully ! </strong> <?=$this->session->flashdata('Succ')?>
                                               </div
                                             ><?php
                                                }
                                             ?>
                                            </h2>
                                           <br>
                                            <div class="form">
                                           <form class="cmxform" id="signupform" class="signupform" method="post" 
                                            action="<?php echo base_url(); ?>NewUser/CreatingUser">
                                           <fieldset class="scheduler-border" style="max-width:90%;display:inline-block;">
                                            <legend class="scheduler-border">Basic Information</legend>
                                            <br>
                                            <div class="building_records_main">
                                             <div class="building_records_main_left">
                                               <label>Name:</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="text" name="username" id="username" value="" class=
                                             "form_input radius4" />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                           <div class="building_records_main">
                                             <div class="building_records_main_left">
                                             
                                               <label>Email: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="text" name="email" id="email" value="" class=
                                             "form_input radius4" />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                            <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                               <label>Category: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right" >
                                              <select class="form_input radius4" style="width:100%" 
                                               name="user_cat_id" id="user_cat_id" required 
                                               onChange="showingUserPermission(this.value);">
                                               <option value="">Select Category</option>
                                               <option value="1">Administrator</option>
                                               <option value="3">Subcontractor</option>
                                               <option value="2">Normal User</option>
                                              
                                              </select>
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                           <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                               <label>Password: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right" >
                                             <input type="password" name="password" id="password" value="" class=
                                             "form_input radius4" />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                          <div class="building_records_main">
                                             <div class="building_records_main_left">
                                           
                                               <label>Confirm Password: *</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                             <input type="password" name="c_password" id="c_password" value="" class=
                                             "form_input radius4" />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           <br><br> <br>
                                           </div>
                                          
                                              
                                            
                                            <br><br> 
                                           <div  id="permission" style="width:100%;" >
                                            <table class="table_styling responsive_table" 
                                            border="1" style="width:100%;color:	
                                             #FFF; border:1px #FFFFFF solid;text-align:center;">
                                            <tr style="background-color:#59A5DF;border-bottom:#353535;vertical-align:central">
                                              <td style="margin-top:10%">Sr #. </td>
                                              <td>Building Name</td>
                                              <td>Visible</td>
                                              <td>Edit</td>
                                            
                                            </tr>
                                          <?php
										  
										   if($this->session->flashdata('Err')==null){
											   $i=0;
				 						      foreach($list_buillding as $data){
										   ?>
                                             <tr id="">
                                              <td><?=++$i; ?></td>
                                              <td><?=$data['ss_address'] ?>
                                              <input type="hidden" id="building_id[]" 
                                              name="building_id[]" value="<?=$data['building_id'] ?>"
                                               
                                               />
                                              </td>
                                              <td><input type="checkbox" name="visible_<?=$data['building_id'] ?>" 
                                              id="visible_<?=$data['building_id'] ?>" 
                                              value="1" checked 
                                              onClick="Visible('edit_<?=$data['building_id']?>',
                                              'visible_<?=$data['building_id'] ?>')"/>
                                              
                                             
                                              
                                              </td>
                                              <td><input type="checkbox" 
                                              id="edit_<?=$data['building_id'] ?>" 
                                              name="edit_<?=$data['building_id'] ?>" value="2" /></td>
                                             
                                            </tr>  
										   <?php 		  
											 }
											}
										  ?>     
                                         </table>
                                      </div>
                                             <br><br>
                                            <div class="building_records_main">
                                             <div class="building_records_main_left">
                                             
                                             </div>  
                                            
                                            <div class="form-group has-feedback building_records_main_right">
                                            <br>
                                               <div class="building_submit_responsive">
                                               
                                               <input type="submit" name="submit" 
                                               class=" custom_form_submit radius4 green 
                                            green_borderbottom" id="submit" value="Create" />
                                               </div>
                                               
                                                <div class="building_cancel_responsive">
                                               
                                                 <input type="button" name="cancel" 
                                                 class="building_cancel_design custom_form_submit radius4  
                                            green_borderbottom" id="cancel" value="Cancel"
                                             onClick="redirect('<?php echo base_url()."NewUser/listUser" ?>');"
                                             style="background-color:#000;color:#fff;" />
                                               </div>
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                          
                                          
                                          
                                         </fieldset>    
                                         
                                         
                                         
                                           
                                        <br><br><br>
                                       
                                            
                                      </form>
                                           
                                           
                                        
                                          
                                         
                                        
                                            </div>

                                          
                                         
                                 
                                       
                                       
  
                                      <!--End of page container-->

     <div class="scrolltop radius20"><a onClick="jQuery('html, body').animate( { scrollTop: 0 }, 'slow' );" 
        href="javascript:void(0);">
       <img src="<?php echo base_url(); ?>static/images/icons/top.png" alt="Go on top" title="Go on top" /></a> 
        
   </div>                                    
         </div>                                        
     
         </div>
    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>
<script src='<?php echo base_url(); ?>static/js/formAnimation.js'></script>
<script src='<?php echo base_url(); ?>static/js/shake.js'></script>

</body>
</html>