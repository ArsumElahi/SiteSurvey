<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
 
  if(!isset($session_data[0]['user_id'])){
     redirect(base_url()."Login/index");
  
  }
  else{
   if($session_data[0]['user_type']!="1"){
	   
	    redirect(base_url()."Login/Home");
   }
   
  }
 if($session_data[0]['user_type']=="3"){
   redirect(base_url()."Login/home");
  }
  
  
?>

<!DOCTYPE html>
<html>
<head>
<title>Survey - Users List</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>

<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.1/modernizr.min.js'></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">


<script src="<?php echo base_url(); ?>static/js/code.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<style>
/* Start CSS for Animation*/
form .form-group.has-error label {
color: #F00;}
form .form-group.has-error label.error {
margin-top: 10px;
margin-bottom: 0;
font-weight: 400;
font-size: 15px;}
form .form-group.has-error input, form .form-group.has-error {
border-color: #F00; }
form .form-group.has-error input:focus, form .form-group.has-error textarea:focus {
border-color: #d9534f;
box-shadow: 0 0 6px #d9534f; }
form .form-group.has-success input, form .form-group.has-success textarea {
border-color: #6fd653; }
form .form-group.has-success input:focus, form .form-group.has-success textarea:focus {
border-color: #6fd653;
box-shadow: 0 0 6px #6fd653; }

/* End CSS for Animation */
</style>

<script type="text/javascript">
 function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
  }
</script>
</head>
<body onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
          
            
            
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">
                                          <div class="page_title_heading_left page_title_building"  >
                                           Users List
                                          </div>
                                          <div class="page_title_heading_right">
                                             <div class="page_title_heading_right_1">
                                               <label> Building Address </label>
                                             </div>
                                              <div class="page_title_heading_right_2">
                                                <label> <?=$building_data[0]['ss_address']?> </label>
                                             </div> 
                                          </div>
                                        </h2>
                                      
                                           <br><br>
                                        <h2 id="Note">
                                               <?php 
                                               if($this->session->flashdata('Err')){
                                                ?>
                                               <div class="custom_alert_error alert" id="myAlert" 
                                               style="display:none;font-size:0.654em;">
                                                        <strong>Error ! </strong> <?=$this->session->flashdata('Err')?>
                                             </div>
                                             <?php
                                                }
                                                if($this->session->flashdata('Succ')){
                                                ?>
                                              <div class="custom_alert_success alert" id="myAlert" 
                                                style="display:none;font-size:0.654em;">
                                                <strong>Successfully ! </strong> <?=$this->session->flashdata('Succ')?>
                                               </div>
                                             <?php
                                                }
                                             ?>
                                       </h2>
                                           <br>
                                            <div class="form">
                                            
                                            <div class="building_records_main">
                                             <div  class="user_link_left_button">
                                                 <a href="<?php echo base_url(); ?>NewUser/" 
                                                 class="pictures_link radius8" title="New User"
                                                 style="font-size:1.5em;">Create Users</a>
                                             </div>  
                                            
                                            <div class="form-group has-feedback
                                            user_link_right_button " 
                                            >
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                           
                                           <form class="cmxform" id="signupform" class="notes_form" method="post" 
                                            action="<?php echo base_url(); ?>NewUser/CreatingUser">
                                          <table class="table_styling responsive_table" border="1" style="width:100%;color:	
                                             #FFF; border:1px #FFFFFF solid;text-align:center">
                                            <tr style="background-color:#59A5DF;border-bottom:#353535">
                                              <td style="margin-top:10%">Sr #. </td>
                                              <td>Username</td>
                                              <td>Email</td>
                                              <td>Category</td>
                                              <td>Status</td>
                                            </tr>
                                           <?php
										  
										   if($this->session->flashdata('Error')==null){
											   $i=0;
				 								foreach($users_list as $users){
				  							?>
                                              <tr>
                                              <td><?=++$i; ?></td>
                                              <td><?=$users['user_name'];?></td>
                                              <td><?=$users['user_email'];?></td>
                                              <td><?php 
											     if($users['user_type']==1){
												    echo "Administrator";
												 
												 }
												 else if($users['user_type']==3){
												  echo "Subcontractor"; 
												  
												 }
												 else{
												  echo "Normal User";
												 }
												 ?>
                                             </td>
                                              <td>
                                              <?php 
												   if($users['user_status']==1){
												      echo "Active";
												   }
												   else{
													   echo "Inactive";
												   }
												 ?>
                                              </td>
                                            </tr>  
                                        <?php 
										}
										   }
										?>     
                                            
                                       
                                         
                                         
                                         
                                           
                                        <br><br><br>
                                      
                                            
                                      </form>
                                           
                                           
                                        
                                          
                                         
                                        
                                            </div>

                                          
                                         
                                 
                                       
                                       
  
                                      <!--End of page container-->

     
         </div>                                        
     
         </div>
    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>
<script src='<?php echo base_url(); ?>static/js/formAnimation.js'></script>
<script src='<?php echo base_url(); ?>static/js/shake.js'></script>

</body>
</html>