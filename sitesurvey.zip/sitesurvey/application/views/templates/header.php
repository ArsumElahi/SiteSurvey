<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');

 if(!isset($session_data[0]['user_id']))
  {
//     redirect(base_url()."Login/index");
  
  }

?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />


<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
</head>
<body >

    
        <div id="header">
               <?php
				if(isset($session_data[0]['user_id'])){
				 
				  if(!isset($page_name)){ ?>
                 <div class="gohome radius20"><a href="<?php echo base_url();?>Login/home" id="homebutton"><img src=
                 "<?php echo base_url(); ?>static/images/icons/home.png" alt="" title="" /></a></div>
                 <?php } else{?>
                  <div class="login_title" style="border:none;">
                  Hello &nbsp;<span style="text-decoration:underline"><?=substr($session_data[0]['user_name'],0,8).".."?>
                  </span></div>
                 <?php }?>
                  <div class="gomenu radius20"><a href="<?=base_url(); ?>login/logout"><img 
                  src="<?php echo base_url(); ?>static/images/icons/logout.png" alt="" title="" /></a></div>
                  
              <?php 
				}else{
				?>
                <div id="header">
                <!--  <div class="gohome radius20"><a href="index.html" id="homebutton"><img src="<?php //echo base_url(); ?>static/images/icons/home.png" alt="" title="" /></a></div> -->
                  <div class="gomenu radius20"><a href="#" id="contactbutton"><img src="<?php echo base_url(); ?>static/images/icons/contact.png" alt="" title="" /></a></div>
            </div>
                <?php
				}
			  
			  ?>    
            </div>
</body>
</html>