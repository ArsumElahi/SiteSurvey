<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html>
<head>
<title>Survey - Sign Up</title>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>

<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.1/modernizr.min.js'></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">

<script src="<?php echo base_url(); ?>static/js/code.js"></script>

<style>
/* Start CSS for Animation*/
form .form-group.has-error label {
color: #F00;}
form .form-group.has-error label.error {
margin-top: 10px;
margin-bottom: 0;
font-weight: 400;
font-size: 15px;}
form .form-group.has-error input, form .form-group.has-error {
border-color: #F00; }
form .form-group.has-error input:focus, form .form-group.has-error textarea:focus {
border-color: #d9534f;
box-shadow: 0 0 6px #d9534f; }
form .form-group.has-success input, form .form-group.has-success textarea {
border-color: #6fd653; }
form .form-group.has-success input:focus, form .form-group.has-success textarea:focus {
border-color: #6fd653;
box-shadow: 0 0 6px #6fd653; }

/* End CSS for Animation */
</style>
</head>
<body>
<div id="wrapper">

    <div id="content">
            <div id="header">
                <!--  <div class="gohome radius20"><a href="index.html" id="homebutton"><img src="<?php //echo base_url(); ?>static/images/icons/home.png" alt="" title="" /></a></div> -->
                  <div class="gomenu radius20"><a href="#" id="contactbutton"><img src="<?php echo base_url(); ?>static/images/icons/contact.png" alt="" title="" /></a></div>
            </div>
            
            
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h3 class="page_title">Sign Up</h3>
                                            <h2 id="Note"></h2>
                                            <div class="form">
                                            <form class="cmxform" id="signupform" class="signupform" method="post" 
                                            action="<?php echo base_url();?>NewUser/">
                                            <label>Username: *</label>
                                            <div class="form-group has-feedback">
                                            <input type="text" name="username" id="username" value="" class="form_input radius4 
                                            " />
                                             
                                            </div>
                                            <label>Email: *</label>
                                            <div class="form-group has-feedback">
                                            <input type="text" name="email" id="email" value="" class="form_input radius4 
                                            " />
                                             
                                            </div>
                                            <label>Password: *</label>
                                          <div class="form-group has-feedback">  
                                            <input type="password" name="password" id="password" value="" class="form_input radius4" />
                                           </div>
                                           <label>Confirm Password: *</label>
                                          <div class="form-group has-feedback">  
                                            <input type="password" name="c_password" id="c_password" value="" class="form_input radius4" />
                                           </div>
                                            
                                            <input type="submit" name="submit" class="form_submit radius4 green green_borderbottom" id="submit" value="Create Account" />
                                            <label id="loader" style="display:none;"><img src="images/loader.gif" alt="Loading..." id="LoadingGraphic" /></label>
                                            </form>
                                            </div>

                                          <h4 style="text-align:center">Have an Account ? 
                                          
                                          <a href="<?php echo base_url();?>Login/index" title="Login">
                                          Login
                                          </a>
                                          </h4>    
                                         
                                 
                                       
                                       
                                        <!--End of page container-->
         </div>
    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>
<script src='<?php echo base_url(); ?>static/js/formAnimation.js'></script>
<script src='<?php echo base_url(); ?>static/js/shake.js'></script>

</body>
</html>