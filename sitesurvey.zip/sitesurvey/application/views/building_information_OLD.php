<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
  if(!isset($session_data[0]['user_id']))
  {
     redirect(base_url()."Login/index");
  
  }

?>

<!DOCTYPE html>
<html>
<head>
<title>Survey -  My Locations</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>


<script src="<?php echo base_url(); ?>static/js/code.js"></script>

</head>
<body>
<div id="wrapper">

    <div id="content">
           <div id="header">
                 <div class="gohome radius20"><a
                                              href="<?php echo base_url();?>Login/home" id="homebutton"><img src=
                 "<?php echo base_url(); ?>static/images/icons/home.png" alt="" title="" /></a></div>
                  <div class="gomenu radius20"><a href="<?=base_url(); ?>login/logout" 
id="contactbutton"><img src="<?php echo base_url(); ?>static/images/icons/logout.png" alt="" title="" /></a></div>
            </div>
            
            
            
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">
                                          <div class="page_title_heading_left page_title_building" style="font-size:0.665em" >
                                           My Locations
                                          </div>
                                          <div class="page_title_heading_right">
                                             <div class="page_title_heading_right_1">
                                               <label> Building Address </label>
                                             </div>
                                              <div class="page_title_heading_right_2">
                                                <label> <?=$building_data[0]['ss_address']?> </label>
                                             </div> 
                                          </div>
                                        </h2>
                                           <br><br><br>
                                            <div class="form">
                                            <form class="cmxform" id="search_building" class="search_building" method="post" 
                                            action="<?=base_url();?>Building/searchBuilding">
                                            <div style="width:85%;float:left">
                                             <div style="width:12%;float:left">
                                               <label>Search:</label>
                                             </div>  
                                            
                                            <div class="form-group has-feedback" style="width:73%;float:right">
                                             <input type="text" name="search" id="search" 
                                             value="<?php if(isset($searched_text)){ echo $searched_text;} ?>" 
                                             class="form_input radius4" />
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                        
                                            </form>
                                           
                                           
                                           <br>  <br><br><br>
                                           <table class="table_styling responsive_table" border="1" style="width:100%;color:	
                                             #FFF; border:1px #FFFFFF solid;text-align:center">
                                            <tr style="background-color:#59A5DF;border-bottom:#353535">
                                              <td style="margin-top:10%">Sr #. </td>
                                              <td>Street</td>
                                              <td>City</td>
                                              <td>State</td>
                                              <td>Zip</td>
                                            </tr>
                                           <?php
										  
										   if($this->session->flashdata('Error')==null){
											   $i=0;
				 								foreach($all_list as $buildings){
				  							?>
                                             <tr <?php if($building_data[0]['building_id']==$buildings['building_id']){
												 ?>
											       style="background-color:#d6e9c6;color:#3c763d"
                                            	 <?php
												 } ?>
                                              >
                                              <td><?=++$i; ?></td>
                                              <td>
											   <a 
                                href="<?=base_url();?>Building/searchExistingLocation?building_id=<?=$buildings['building_id'];?>"
                                               title="<?=$buildings['ss_address'] ?>" 
                                               <?php if($building_data[0]['building_id']==$buildings['building_id']){
												 ?>
											       style="color:#3c763d"
                                            	 <?php
												 } ?>>
											   <?=$buildings['street'] ?>
                                               </a>
                                              </td>
                                              <td><?=$buildings['city'] ?></td>
                                              <td><?=$buildings['state'] ?></td>
                                              <td><?=$buildings['zip'] ?></td>
                                            </tr>  
                                        <?php 
										}
										   }
										?>     
										 
                                           
                                         </table>
                                        
                                            
                                            </div>

                                          
                                         
                                 
                                       
                                       
                                        <!--End of page container-->

    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>

</body>
</html>