<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
  $permission_data = $this->session->userdata('permission');
  if(!isset($session_data[0]['user_id']))
  {
     redirect(base_url()."Login/index");
  
  }
  if($session_data[0]['user_type']=="3"){
   redirect(base_url()."Login/home");
  }
// $occurence =array(); 
 for($k=0;$k<sizeof($permission_data);$k++){
	 for($i=$k+1;$i<sizeof($permission_data);$i++){
	     if($permission_data[$k]['user_id']==$permission_data[$i]['user_id'] && $permission_data[$k]['building_id']==$permission_data[$i]['building_id'] ){
		   $permission_data[$i]['building_id'] =0;
		 }
	 
	 }
 
 }
 $call ="0";
?>



<!DOCTYPE html>
<html>
<head>
<title>Survey -  Trash</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>
<style>
.button_style{
  background-color:#015A9F;
  color:#FFF;
  border:none;
}
</style>

<script src="<?php echo base_url(); ?>static/js/code.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
 
    <script src="http://ajax.aspnetcdn.com/ajax/modernizr/modernizr-2.8.3.js"></script>
    <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.1/jquery-ui.min.js"></script>

   
   <script src="<?php echo base_url(); ?>static/Scripts/js/infragistics.core.js"></script>
   <script src="<?php echo base_url(); ?>static/Scripts/js/infragistics.lob.js"></script>
   <link href="<?php echo base_url(); ?>static/Scripts/css/themes/infragistics/infragistics.theme.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>static/Scripts/css/structure/infragistics.css" rel="stylesheet" /> 

    
<script>
function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
  }
</script>
<?php require_once("load_data.php"); ?>
</head>
<body onLoad="errorwithsliding()">


<div id="wrapper">

    <div id="content">
           
            
            
            
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">
                                          <div class="page_title_heading_left page_title_building" style="font-size:0.665em" >
                                           Trash Buildings
                                          </div>
                                          <div class="page_title_heading_right">
                                             <div class="page_title_heading_right_1">
                                               <label> Building Address </label>
                                             </div>
                                              <div class="page_title_heading_right_2">
                                                <label> <?=$building_data[0]['ss_address']?> </label>
                                             </div> 
                                          </div>
                                        </h2>
                                           <br><br>
                                           <h2 id="Note">
                                               <?php 
                                                if($this->session->flashdata('Err')){
                                                ?>
                                               <div class="custom_alert_error alert" id="myAlert" 
                                               style="display:none;font-size:0.654em;">
                                                        <strong>Error ! </strong> <?=$this->session->flashdata('Err')?>
                                             </div>
                                             <?php
                                                }
                                             
                                                if($this->session->flashdata('Succ')){
                                                ?>
                                              <div class="custom_alert_success alert" id="myAlert" 
										  	style="display:none;font-size:0.654em;">
										  	    <strong>Successfull ! </strong> <?=$this->session->flashdata('Succ')?>
										     </div>
                                             <?php
                                                }
                                             ?>
                                            </h2><br>
                                            <div class="form">
                                            
                                           
                                           <br><br><br>
                                       
                                          <table id="grid" width="100%"></table>
                                       
    <script>
     /*   $(function () {
            
            $("#grid").igGrid({
                primaryKey: "ProductID",
                margin:'20px',
				width: '90%',
				
                columns: [
                    { headerText: "Product ID", key: "ProductID", dataType: "number", width: "15%", hidden: true },
                    
                    { headerText: "Product Name", key: "ProductName", dataType: "string", width: "25%" },
                    { headerText: "Category", key: "CategoryName", dataType: "string", width: "25%" },
                    { headerText: "Units In Stock", key: "InStock", dataType: "number", width: "35%" }
                ],
                autofitLastColumn: false,
                autoGenerateColumns: false,
                dataSource:northwindProducts,
                responseDataKey: "results",
                autoCommit: true,
                features: [
                    {
                        name: "Sorting",
                        sortingDialogContainment: "window"
                    },
                    {
                        name: "Filtering",
                        type: "local",
                        columnSettings: [
                            {
                                columnKey: "ImageUrl",
                                allowFiltering: false
                            },
                            {
                                columnKey: "InStock",
                                condition: "greaterThan"
                            }
                        ]
                    },
                  
                    
                    {
                        name: "Paging",
                        pageSize: 10
                    },
                    {
                        name: "Resizing"
                    },
                   
                ]
            });
        });
*/
        $(function () {
           
		    $("#grid").igGrid({
                primaryKey: "building_id",
                margin:'20px',
				width: '100%',
				
                columns: [
                  
                    { headerText: "Building ID", key: "building_id", dataType: "string", width: "15%", hidden: true },
					{ headerText: "Duplicates", key: "duplicate", dataType: "string", width: "15%",hidden:true} ,	
                    { headerText: "Street", key: "street", dataType: "string", width: "25%"},
                    { headerText: "City", key: "city", dataType: "string", width: "25%"},
                    { headerText: "State", key: "state", dataType: "string", width: "25%"} ,
					{ headerText: "Address", key: "ss_address", dataType: "string", width: "35%"} ,
			        { headerText: "Sub Contractor", key: "user_name", dataType: "string", width: "25%"} ,
				
				    { headerText: "Date", key: "created_date", dataType: "date", width: "25%",format: "dd-MMM-yyyy"} ,
				    { headerText: "Action", key: "undone", dataType: "string", width: "20%",
					template: "<input type='button' onclick='restore(${building_id})' value='Restore' class='button_style'/>" },
                
                ],
                autofitLastColumn: false,
                autoGenerateColumns: false,
                dataSource: buildings_data,
                responseDataKey: "results",
                autoCommit: true,
               features: [
                   {
                        name: "Sorting",
                        sortingDialogContainment: "window"
                    },
					
                    {
                        name: "Filtering",
                        type: "local",
                         columnSettings: [
                            {
                                columnKey: "undone",
                                allowFiltering: false
                            }
							
                       ] 
                      
                     },
                 
                  {
                        name: "Paging",
                        pageSize: 10
                    },
              
			        {
                        name: "Resizing"
                    },
                   
                ]
            });
        });
   /* 
  $("#grid").click(function (event) {
     var row = $(event.target).closest('tr');
     var key = row.attr("data-id");
     if(key!=null){
	   window.location = '<?=base_url();?>Building/searchExistingLocation?building_id='+key;
	  
	 }
}
);
 
$(document).ready(function(event) {
   
    var myRows = $("#grid").igGrid( "allRows" );
	
	
	for(var i=0;i<myRows.length;i++){
		rowIndex = i;
	    dataSource = $("#grid").igGrid("option", "dataSource");
	    pageIndex = $("#grid").igGridPaging("option", "currentPageIndex");
	    pageSize = $("#grid").igGridPaging("option", "pageSize");
		
		
	  if(pageIndex === 0){
	   cellValue = dataSource[rowIndex].duplicate;
	   if(cellValue=="yes"){
		   var row = $("#grid").igGrid("rowAt", rowIndex);
		    $(row.cells).each(function (i) {

                    var cell = $("#grid").igGrid('cellAt', i, rowIndex);
                    $(cell).css("color", "#FFF");
					$(row).css("background-color", "##59A5DF");                     

                  
                });


	    
		}
		  
	   }
	  
	  else{
	   
	   cellValue = dataSource[pageIndex*pageSize + rowIndex].duplicate;
	   if(cellValue=="yes"){
		    var row = $("#grid").igGrid("rowAt", rowIndex);
		    $(row.cells).each(function (i) {

                    var cell = $("#grid").igGrid('cellAt', i, rowIndex);
                    $(cell).css("color", "#FFF");
					$(row).css("background-color", "##59A5DF");                     

                  
                });
	   }

	  }

	}
	
	
});  */
  function restore(id){
     if(confirm('Are you Sure you want to Restore this Record ?')){
	  window.location = "<?=base_url();?>Building/restore?id="+id;
	 }
  }
     </script>
                                            
                                            </div>

                                          
                                         
                                 
                                       
                                       
                                        <!--End of page container-->

    </div>
</div> 

 
</body>
</html>