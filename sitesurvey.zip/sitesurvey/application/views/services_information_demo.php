<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
  $permission_data = $this->session->userdata('permission');
 
  if(!isset($session_data[0]['user_id']))
  {
     redirect(base_url()."Login/index");
  
  }
  
  if($session_data[0]['user_type']=="3"){
   redirect(base_url()."Login/home");
  }
  
  if(empty($building_data[0]['building_id'])){
	   redirect(base_url()."Login/error");
  }
  
    
 $edit=0;
   for($j=0;$j<sizeof($permission_data);$j++){
		if($building_data[0]['building_id']==$permission_data[$j]['building_id']){
			if($permission_data[$j]['permission_type']=="2"){
			   $edit =1;
			}
		}
  }
?>

<!DOCTYPE html>
<html>
<head>
<title>Survey - Services</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />


<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>static/date_time_plugin/jquery.datetimepicker.css"/ >
<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.1/modernizr.min.js'></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">

<script src="<?php echo base_url(); ?>static/js/code.js"></script>
<style type="text/css">
  tr.Border td {border: 1px solid #000; background:#59A5DF}
  .one_border {border: 1px solid #000; background:#59A5DF}
  
</style>
<script>
function changeValue(value,id,type){
 if(document.getElementById(id).checked){
   if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      
    }
  }
  
  xmlhttp.open("GET","<?=base_url();?>Services/servicesCheck?type="+type+"&value="+value,true);
  xmlhttp.send();
 
 }
 else{
     if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		  } else { // code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		  xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			  
			}
		  }
		  
		  xmlhttp.open("GET","<?=base_url();?>Services/servicesCheck?type="+type+"&value="+value+"&delete=1",true);
		  xmlhttp.send();
 }

}


function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
  }

</script>
<script>
function changeDate(value,id,type){
	
 if(document.getElementById(id).value!=""){
   
   if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      
    }
  }
  
  xmlhttp.open("GET","<?=base_url();?>Services/servicesCheck?delete=1&date=1&type="+type+"&value="+value,true);
  xmlhttp.send();
 
 }
}
function previousValue(value,id,type){
	 if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	  } else { // code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	  xmlhttp.onreadystatechange=function() {
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
		  
		}
	  }
	  
	  xmlhttp.open("GET","<?=base_url();?>Services/servicesCheck?delete=1&type="+type+"&value="+value,true);
	  xmlhttp.send();
 
}
 
 
</script>

</head>


<body onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">
                                          <div class="page_title_heading_left page_title_building" >
                                           Services
                                          </div>
                                          <div class="page_title_heading_right">
                                             <div class="page_title_heading_right_1">
                                               <label> Building Address </label>
                                             </div>
                                              <div class="page_title_heading_right_2">
                                                <label> <?=$building_data[0]['ss_address']?> </label>
                                             </div> 
                                          </div>
                                        </h2>
                                           <br><br>
                                            <h2 id="Note">
												 <?php 
                                                 if($this->session->flashdata('Err')){
                                                 ?>
                                                 <div class="custom_alert_error alert" id="myAlert" 
                                                 style="display:none;font-size:0.654em;">
                                                 <strong>Error ! </strong> <?=$this->session->flashdata('Err')?>
                                                 </div>
                                                <?php
                                                }
                                                else if($this->session->flashdata('Succ')){
                                                ?>
                                                <div class="custom_alert_success alert" id="myAlert" 
                                                style="display:none;font-size:0.654em;">
                                                <strong>Successfull ! </strong> <?=$this->session->flashdata('Succ')?>
                                               </div>
                                               <?php
                                               }
                                               ?>
          								  </h2>
                                           
                                           <br>
                                            <div class="form">
                                           <table class="table_styling responsive_table" border="1" style="width:100%;color:	
                                             #FFF; border:1px #FFFFFF solid;text-align:center">
                                            <tr style="background-color:#59A5DF;border-bottom:#353535">
                                              <td style="margin-top:10%;">&nbsp;</td>
                                              <td>Available</td>
                                              <td>RFS Date </td>
                                              <td>Connected</td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;Dark Fiber</td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="dark_available" id="dark_available" value="1" 
                                              onClick="changeValue('1','dark_available','1')"
                                              <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="1" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											   if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                            <div class="control__indicator"></div>  
                                            </label>
                                            </td>
                                              <td> 
                                              
                                             <input type="text" name="dark_date" id="dark_date" class=
                                             "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                              onBlur="changeDate(dark_date.value,'dark_date','1')" 
                                              onClick="previousValue(dark_date.value,'dark_date','1')"
                                              value="<?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="1" && strpos($result['service_value'], '-') &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo $result['service_value'];
												  }
												}
											   }
											  ?> "  <?php if($session_data[0]['user_type']=="2") if($edit==0){?> disabled <?php } ?>/> 
                                             
                                             </td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="dark_connected" id="dark_connected" value="1"
                                              onClick="changeValue('3','dark_connected','1')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="1" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											    if($session_data[0]['user_type']=="2") if($edit==0){?> disabled <?php } ?>>
                                             <div class="control__indicator"></div>  
                                             </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;DAS</td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="das_available" id="das_available" value="1"
                                                onClick="changeValue('1','das_available','2')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="2" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){?> disabled<?php } ?> >
                                              <div class="control__indicator"></div>  
                                              </label>
                                              </td>
                                              <td>
                                              <input type="text" name="das_date" id="das_date" class=
                                             "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                             onBlur="changeDate(das_date.value,'das_date','2')" 
                                             onClick="previousValue(das_date.value,'das_date','2')"
                                             value="<?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="2" && strpos($result['service_value'], '-') &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo $result['service_value'];
												  }
												}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2") if($edit==0){?> disabled <?php } ?>/>
                                              </td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="das_connected" id="das_connected" value="1"
                                               onClick="changeValue('3','das_connected','2')"
                                                <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												 
												  if($result['service_type']=="2" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												  
												}
											   }
											 if($session_data[0]['user_type']=="2")  if($edit==0){ ?> disabled <?php }?>
                                               
                                               >
                                              
                                               <div class="control__indicator"></div> 
                                              </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;Small Cell</td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="cell_available" id="cell_available" value="1"
                                              onClick="changeValue('1','cell_available','3')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="3" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2")  if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>  
                                              </label>
                                              </td>
                                              <td>
                                              <input type="text" name="cell_date" id="cell_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(cell_date.value,'cell_date','3')" 
                                                 onClick="previousValue(cell_date.value,'cell_date','3')"
                                                 value="<?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="3" && strpos($result['service_value'], '-') &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo $result['service_value'];
												  }
												}
											   }
											  ?>"  <?php if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>/>
                                              </td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="cell_connected" id="cell_connected" value="1"
                                              onClick="changeValue('3','cell_connected','3')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="3" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>  
                                              </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;Conduit</td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="con_available" id="con_available" value="1"
                                              onClick="changeValue('1','con_available','4')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="4" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>  
                                              </label> 
                                              </td>
                                              <td>
                                               <input type="text" name="con_date" id="con_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(con_date.value,'con_date','4')" 
                                                 onClick="previousValue(con_date.value,'con_date','4')"
                                                 value="<?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="4" && strpos($result['service_value'], '-') &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo $result['service_value'];
												  }
												}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>/>
                                              </td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="con_connected" id="con_connected" value="1"
                                              onClick="changeValue('3','con_connected','4')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="4" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											   if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>  
                                              </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;Wavelength</td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="wave_available" id="wave_available" value="1"
                                               onClick="changeValue('1','wave_available','5')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="5" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                              <td>
                                             
                                              <input type="text" name="wave_date" id="wave_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(wave_date.value,'wave_date','5')" 
                                                 onClick="previousValue(wave_date.value,'wave_date','5')"
                                                 value="<?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="5" && strpos($result['service_value'], '-') &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo $result['service_value'];
												  }
												}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>/>
                                              </td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="wave_connected" id="wave_connected" value="1"
                                               onClick="changeValue('3','wave_connected','5')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="5" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											   if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;Wifi</td>
                                              <td>
                                              <label class="control control--checkbox">
                                              <input type="checkbox" name="wifi_available" id="wifi_available" value="1"
                                               onClick="changeValue('1','wifi_available','6')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="6" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											   if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                              <td>
											  <input type="text" name="wifi_date" id="wifi_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(wifi_date.value,'wifi_date','6')" 
                                                 onClick="previousValue(wifi_date.value,'wifi_date','6')"
                                                 value="<?php
												   if($this->session->flashdata('Err')==null){
													foreach($check_result as $result){
													  if($result['service_type']=="6" && strpos($result['service_value'], '-') &&
													  $result['building_id']==$building_data[0]['building_id']){
														   echo $result['service_value'];
													  }
													}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>/>                                             
                                              </td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="wifi_connected" id="wifi_connected" value="1"
                                               onClick="changeValue('3','wifi_connected','6')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="6" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2")  if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;Ethernet</td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="ethe_available" id="ethe_available" value="1"
                                               onClick="changeValue('1','ethe_available','7')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="7" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                              <td>
                                              <input type="text" name="ethe_date" id="ethe_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(ethe_date.value,'ethe_date','7')" 
                                                 onClick="previousValue(ethe_date.value,'ethe_date','7')"
                                                 value="<?php
												   if($this->session->flashdata('Err')==null){
													foreach($check_result as $result){
													  if($result['service_type']=="7" && strpos($result['service_value'], '-') &&
													  $result['building_id']==$building_data[0]['building_id']){
														   echo $result['service_value'];
													  }
													}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2")  if($edit==0){ ?> disabled <?php }?>/>      
                                              </td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="ethe_connected" id="ethe_connected" value="1"
                                               onClick="changeValue('3','ethe_connected','7')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="7" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;Broadband</td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="broa_available" id="broa_available" value="1"
                                              onClick="changeValue('1','broa_available','8')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="8" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											   if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                              <td>
                                              <input type="text" name="broa_date" id="broa_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(broa_date.value,'broa_date','8')" 
                                                 onClick="previousValue(broa_date.value,'broa_date','8')"
                                                 value="<?php
												   if($this->session->flashdata('Err')==null){
													foreach($check_result as $result){
													  if($result['service_type']=="8" && strpos($result['service_value'], '-') &&
													  $result['building_id']==$building_data[0]['building_id']){
														   echo $result['service_value'];
													  }
													}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2")  if($edit==0){ ?> disabled <?php }?>/>   
                                              </td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="broa_connected" id="broa_connected" value="1"
                                              onClick="changeValue('3','broa_connected','8')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="8" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;Internet</td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="inte_available" id="inte_available" value="1"
                                              onClick="changeValue('1','inte_available','9')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="9" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                              <td>
                                              <input type="text" name="inte_date" id="inte_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(inte_date.value,'inte_date','9')" 
                                                 onClick="previousValue(inte_date.value,'inte_date','9')"
                                                 value="<?php
												   if($this->session->flashdata('Err')==null){
													foreach($check_result as $result){
													  if($result['service_type']=="9" && strpos($result['service_value'], '-') &&
													  $result['building_id']==$building_data[0]['building_id']){
														   echo $result['service_value'];
													  }
													}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2")  if($edit==0){ ?> disabled <?php }?>/>   
                                              </td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="inte_connected" id="inte_connected" value="1"
                                              onClick="changeValue('3','inte_connected','9')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="9" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											 if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                              
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;VoIP</td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="voip_available" id="voip_available" value="1"
                                              onClick="changeValue('1','voip_available','10')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="10" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											 if($session_data[0]['user_type']=="2")  if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                              <td>
                                               <input type="text" name="voip_date" id="voip_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(voip_date.value,'voip_date','10')" 
                                                 onClick="previousValue(voip_date.value,'voip_date','10')"
                                                 value="<?php
												   if($this->session->flashdata('Err')==null){
													foreach($check_result as $result){
													  if($result['service_type']=="10" && strpos($result['service_value'], '-') &&
													  $result['building_id']==$building_data[0]['building_id']){
														   echo $result['service_value'];
													  }
													}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>/>    
                                              </td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="voip_connected" id="voip_connected" value="1"
                                              onClick="changeValue('3','voip_connected','10')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="10" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td align="left">&nbsp;SIP</td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="sip_available" id="sip_available" value="1"
                                              onClick="changeValue('1','sip_available','11')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="11" && $result['service_value']=="1" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                              <td>
                                              
                                              <input type="text" name="sip_date" id="sip_date" class=
                                                 "form_input radius4" autocomplete="off" style="width:50%;height:60%" 
                                                 onBlur="changeDate(sip_date.value,'sip_date','11')" 
                                                 onClick="previousValue(sip_date.value,'sip_date','11')"
                                                 value="<?php
												   if($this->session->flashdata('Err')==null){
													foreach($check_result as $result){
													  if($result['service_type']=="11" && strpos($result['service_value'], '-') &&
													  $result['building_id']==$building_data[0]['building_id']){
														   echo $result['service_value'];
													  }
													}
											   }
											  ?>" <?php if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>/>    
                                              </td>
                                              <td>
                                              <label class="control control--checkbox"> 
                                              <input type="checkbox" name="sip_connected" id="sip_connected" value="1"
                                              onClick="changeValue('3','sip_connected','11')"
                                               <?php
											   if($this->session->flashdata('Err')==null){
											    foreach($check_result as $result){
												  if($result['service_type']=="11" && $result['service_value']=="3" &&
												  $result['building_id']==$building_data[0]['building_id']){
													   echo "checked=checked";
												  }
												}
											   }
											  if($session_data[0]['user_type']=="2") if($edit==0){ ?> disabled <?php }?>>
                                              <div class="control__indicator"></div>
                                              </label>
                                              </td>
                                            </tr>
                                           </table> 
                                          </div>

                                          
                                         
                                 
                                       
                                       
                                        <!--End of page container-->

    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>static/date_time_plugin/jquery.datetimepicker.full.js"></script>
<script src='<?php echo base_url(); ?>static/js/formAnimation.js'></script>




<script>/*
window.onerror = function(errorMsg) {
	$('#console').html($('#console').html()+'<br>'+errorMsg)
}*/

$('#dark_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#sip_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#voip_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});


$('#inte_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});


$('#broa_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#ethe_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#wifi_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#wave_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#con_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#cell_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#das_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});

$('#sip_date').datetimepicker({
	lang:'ch',
	timepicker:false,
	format:'d-M-Y',
	formatDate:'Y-M-d',
	
});




</script>

</body>
</html>