<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
 
  if(!isset($session_data[0]['user_id']))
  {
     redirect(base_url()."Login/index");
  
  }

?>
<!DOCTYPE html>
<html>
<head>
<title>Survey - Popup</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />


</head>
<body >
<img src="<?=$path?>"  alt="Thumbnail"
height="500px" width="400px"/>

                                        
                                          
                                        
                                           
                                  

</body>
</html>