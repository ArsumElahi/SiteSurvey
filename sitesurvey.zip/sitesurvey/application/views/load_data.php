<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
  $permission_data = $this->session->userdata('permission');
 $rows = array();
 $count = 0;
  if($call=="picture"){
	  
	    $edit=0;
   for($j=0;$j<sizeof($permission_data);$j++){
		if($building_data[0]['building_id']==$permission_data[$j]['building_id']){
			if($permission_data[$j]['permission_type']=="2"){
			   $edit =1;
			}
		}
		
		
  }
   if($this->session->flashdata('Err')==null){
				foreach($link as $data){
				   $rows[] = $data;
				   $count++;
				 }
	}
	 echo '<script>var picture_data= '. json_encode($rows).'</script>';
  }
  else if($call=="videos"){
   if($this->session->flashdata('Err')==null){
		foreach($list as $videos){
			   $rows[] = $videos;
			   $count++;
		}
   }
  echo '<script>var videos_data= '. json_encode($rows).'</script>';
  }
  else if($call=="attachment"){
  if($this->session->flashdata('Err')==null){
		foreach($all_list as $attachments){
		   
		   $row['attachment_name'] = $attachments['attachment_name'];
		   $row['attachment_thumbnail'] = $attachments['attachment_thumbnail'];
		   $row['attachment_path'] = $attachments['attachment_path'];
		   $row['capture_date'] = $attachments['capture_date'];
		    if($attachments['attachment_category']=="1"){
              $row['attachment_category'] = "Tests";
			}
			else{
			  $row['attachment_category'] = "All Other Attachments";
			}
		   $rows[] = $row;
		   
	       $count++;
		}
   }
  echo '<script>var attachment_data= '. json_encode($rows).'</script>';
  }
  else if($call=="support"){
  if($this->session->flashdata('Err')==null){
			for($j=0;$j<sizeof($result);$j++){
				  		
			   $row['ticket_no'] = $result[$j]['ticket_no'];
			   $row['ticket_desc'] = $result[$j]['ticket_desc'];
			   $row['response'] ="No response"; 
			   $row['ticket_status'] = $result[$j]['ticket_status'];					
               
			   $rows[] = $row;
		   
	           $count++;
			 }
	}
	
  echo '<script>var support_data= '. json_encode($rows).'</script>';
  }
  else if($call=="contacts"){
   if($this->session->flashdata('Err')==null){
		foreach($list as $contact){
			 $rows[] = $contact;
		}
   }
    echo '<script>var contact_data= '. json_encode($rows).'</script>';
  }
  else if($call=="users"){
   if($this->session->flashdata('Err')==null){
		foreach($users_list as $users){
		   $row['user_name'] = $users['user_name'];
		   $row['user_email'] = $users['user_email'];
		   $row['user_id'] = $users['user_id'];
		   
		    if($users['user_type']=="1"){
              $row['user_type'] = "Administrator";
			}
			else if($users['user_type']==3){
			  $row['user_type'] = "Subcontractor";
			}
			else{
			 $row['user_type'] = "Normal User";
			}
			
			 if($users['user_status']==1){
					$row['user_status'] = "Active";
			 }
			 else{
			 $row['user_status'] = "Inactive";
			 
			 }
												   
		 
		   $rows[] = $row;
		   
	       $count++;
		}
   }
    echo '<script>var users_data= '. json_encode($rows).'</script>';
  }
  else{
  for($k=0;$k<sizeof($permission_data);$k++){
	 for($i=$k+1;$i<sizeof($permission_data);$i++){
	     if($permission_data[$k]['user_id']==$permission_data[$i]['user_id'] && $permission_data[$k]['building_id']==$permission_data[$i]['building_id'] ){
		   $permission_data[$i]['building_id'] =0;
		 }
	 
	 }
 
 }

if($this->session->flashdata('Err')==null){
 
					 if($session_data[0]["user_type"]=="2"){
						for($i=0;$i<sizeof($all_list);$i++){
									 $k=0;
							 for($j=0;$j<sizeof($permission_data);$j++){
							  if($all_list[$i]['building_id']==$permission_data[$j]['building_id']){
							     
								  for($m=0;$m<sizeof($all_list);$m++){
								      if($i!=$m){
								      if($all_list[$i]['latitude']==$all_list[$m]['latitude'] &&
									  $all_list[$i]['longitude']==$all_list[$m]['longitude']){
									   
										 $row['duplicate'] = "yes";
									 $k=1;
									break;
									
									 }
									}
								}
								if($k==0){
								      $row['duplicate'] = "No";
									 }
								   
								   $row['building_id'] = $all_list[$i]['building_id'];
								   $row['street'] = $all_list[$i]['street'];
								   $row['city'] = $all_list[$i]['city'];
								   $row['state'] = $all_list[$i]['state']; 
								   $row['ss_address'] = $all_list[$i]['ss_address'];
								   $row['user_name'] = $all_list[$i]['user_name'];
								   $row['created_date'] = $all_list[$i]['created_date'];
								   $row['user_designation'] = $session_data[0]["user_type"];
								  
								 
								   $rows[] = $row;
							   $count++;
				  							
                                               
							   }
							     }
								   }
									 }
								else{
								for($i=0;$i<sizeof($all_list);$i++){
									 $k=0;
									 for($j=0;$j<sizeof($all_list);$j++){
								      if($i!=$j){
								      if($all_list[$i]['latitude']==$all_list[$j]['latitude'] &&
									  $all_list[$i]['longitude']==$all_list[$j]['longitude']){
									   
										 $row['duplicate'] = "yes";
									 $k=1;
									break;
									
									 }
									}
								}
									if($k==0){
								      $row['duplicate'] = "No";
									 }
								   $row['building_id'] = $all_list[$i]['building_id'];
								   $row['street'] = $all_list[$i]['street'];
								   $row['city'] = $all_list[$i]['city'];
								   $row['state'] = $all_list[$i]['state']; 
								   $row['ss_address'] = $all_list[$i]['ss_address'];
								   $row['user_name'] = $all_list[$i]['user_name'];
								   $row['created_date'] = $all_list[$i]['created_date'];
								   $row['user_designation'] = $session_data[0]["user_type"];
								   
								  $rows[] = $row;
								 $count++;
								  }
							    }

}

 //header("Content-type: application/json");
 // $arr = mysql_fetch_array($recCount);
 
  echo '<script>var buildings_data= '. json_encode($rows).'</script>';
  // echo json_encode($rows);
}

?>
