<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html>
<head>
<title>Survey - Login</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>

<script src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.1/modernizr.min.js'></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">

<script src="js/code.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>





<style>
/* Start CSS for Animation*/
form .form-group.has-error label {
color: #F00;}
form .form-group.has-error label.error {
margin-top: 10px;
margin-bottom: 0;
font-weight: 400;
font-size: 15px;}
form .form-group.has-error input, form .form-group.has-error {
border-color: #F00; }
form .form-group.has-error input:focus, form .form-group.has-error textarea:focus {
border-color: #d9534f;
box-shadow: 0 0 6px #d9534f; }
form .form-group.has-success input, form .form-group.has-success textarea {
border-color: #6fd653; }
form .form-group.has-success input:focus, form .form-group.has-success textarea:focus {
border-color: #6fd653;
box-shadow: 0 0 6px #6fd653; }

/* End CSS for Animation */
</style>

<script type="text/javascript">
 function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
  }
</script>
</head>
<body  onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
          
       <div class="sliderbg">
                                        <div class="pages_container">
                                         <img src="<?php echo base_url(); ?>static/images/icons/logo.png" alt="" title="" 
                                         width="170px" height="100px" style="display:block;margin:0 auto;" />
                                        <h2 class="page_title"><br>Login</h2>
                                       <h2 id="Note">
                                       <?php 
										if($this->session->flashdata('Error')){
										?>
                                       <div class="custom_alert_error alert" id="myAlert" style="display:none;font-size:0.654em;">
      						  					<strong>Error ! </strong> <?=$this->session->flashdata('Error')?>
    		    	                 </div>
                                     <?php
										}
										if($this->session->flashdata('msg')){
									 ?> 
                                      <div class="custom_alert_success alert" id="myAlert" 
                                      style="display:none;font-size:0.654em;">
      						  					<strong>Success ! </strong> <?=$this->session->flashdata('msg')?>
    		    	                 </div>
                                     <?php 
										}
									 ?>
                                     </h2>
                                            <div class="form">
                                            <form class="cmxform" id="loginform" class="loginform" 
                                            method="post" action="<?php echo base_url();?>Login/logininfo">
                                            <label>Email: *</label>
                                            <div class="form-group has-feedback">
                                            <input type="text" name="email" id="email" value="" class="form_input radius4 
                                            " />
                                             
                                            </div>
                                            <label>Password: *</label>
                                          <div class="form-group has-feedback">  
                                            <input type="password" name="password" id="password" value="" class="form_input radius4" />
                                           </div>
                                            <input type="submit" name="submit" class="form_submit radius4 green green_borderbottom" id="submit" value="Login" />
                                            <label id="loader" style="display:none;"><img src="images/loader.gif" alt="Loading..." id="LoadingGraphic" /></label>
                                            </form>
                                            </div>

                                          <h4 style="text-align:center">Don't Have an Account ? 
                                          
                                          <a href="<?php echo base_url();?>Account/index" title="Create New Account">
                                          Sign Up
                                          </a>
                                          </h4>    
                                         
                                 
                                       
                                       
                                        <!--End of page container-->
         </div>
    </div>
</div> 
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.tabify.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.10.1.min.js"></script>
<script src="<?php echo base_url(); ?>static/js/jquery.validate.min.js" type="text/javascript"></script>
<script src='<?php echo base_url(); ?>static/js/formAnimation.js'></script>
<script src='<?php echo base_url(); ?>static/js/shake.js'></script>

</body>
</html>