<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
  $session_data = $this->session->userdata('result');
  $building_data = $this->session->userdata('search_building_result');
  $permission_data = $this->session->userdata('permission'); 
  if(!isset($session_data[0]['user_id'])){
     redirect(base_url()."Login/index");
  
  }
  if($session_data[0]['user_type']=="3"){
   redirect(base_url()."Login/home");
  }
  
  if(empty($building_data[0]['building_id'])){
	   redirect(base_url()."Login/error");
  }
 $edit=0;
   for($j=0;$j<sizeof($permission_data);$j++){
		if($building_data[0]['building_id']==$permission_data[$j]['building_id']){
			if($permission_data[$j]['permission_type']=="2"){
			   $edit =1;
			}
		}
  }
  $call =$call_from;
?>

<!DOCTYPE html>
<html>
<head>
<title>Survey - Contacts List</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/colors/corporate/corporate.css"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>static/css/swipebox.css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'/>


<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css">


<script src="<?php echo base_url(); ?>static/js/code.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/modernizr/modernizr-2.8.3.js"></script>
    <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.1/jquery-ui.min.js"></script>

   
   <script src="<?php echo base_url(); ?>static/Scripts/js/infragistics.core.js"></script>
   <script src="<?php echo base_url(); ?>static/Scripts/js/infragistics.lob.js"></script>
   <link href="<?php echo base_url(); ?>static/Scripts/css/themes/infragistics/infragistics.theme.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>static/Scripts/css/structure/infragistics.css" rel="stylesheet" /> 
<style>
/* Start CSS for Animation*/
form .form-group.has-error label {
color: #F00;}
form .form-group.has-error label.error {
margin-top: 10px;
margin-bottom: 0;
font-weight: 400;
font-size: 15px;}
form .form-group.has-error input, form .form-group.has-error {
border-color: #F00; }
form .form-group.has-error input:focus, form .form-group.has-error textarea:focus {
border-color: #d9534f;
box-shadow: 0 0 6px #d9534f; }
form .form-group.has-success input, form .form-group.has-success textarea {
border-color: #6fd653; }
form .form-group.has-success input:focus, form .form-group.has-success textarea:focus {
border-color: #6fd653;
box-shadow: 0 0 6px #6fd653; }

/* End CSS for Animation */
</style>

<script type="text/javascript">
 function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
  }
</script>
<?php require_once("load_data.php");?>
</head>
<body onLoad="errorwithsliding()">
<div id="wrapper">

    <div id="content">
            
       <div class="sliderbg">
                                        <div class="pages_container">
                                        
                                        <h2 class="page_title">
                                          <div class="page_title_heading_left page_title_building"  >
                                           Contacts List
                                          </div>
                                          <div class="page_title_heading_right">
                                             <div class="page_title_heading_right_1">
                                               <label> Building Address </label>
                                             </div>
                                              <div class="page_title_heading_right_2">
                                                <label> <?=$building_data[0]['ss_address']?> </label>
                                             </div> 
                                          </div>
                                        </h2>
                                      
                                           <br><br>
                                        <h2 id="Note">
                                               <?php 
                                               if($this->session->flashdata('Err')){
                                                ?>
                                               <div class="custom_alert_error alert" id="myAlert" 
                                               style="display:none;font-size:0.654em;">
                                                        <strong>Error ! </strong> <?=$this->session->flashdata('Err')?>
                                             </div>
                                             <?php
											   }
											   else if($this->session->flashdata('Succ')){
										 	 ?>
 											  <div class="custom_alert_success alert" id="myAlert" 
										  	style="display:none;font-size:0.654em;">
										  	    <strong>Successfull ! </strong> <?=$this->session->flashdata('Succ')?>
										     </div>
										   <?php
										     }
                 						   ?>
                                       </h2>
                                           <br>
                                            <div class="form">
                                           <?php    
										   if($session_data[0]['user_type']=="2"){ 
										    if($edit==1){ ?>   
                                            <div class="building_records_main">
                                             <div  class="user_link_left_button">
                                                 <a href="<?php echo base_url(); ?>Contacts/" 
                                                 class="pictures_link radius8" title="New Contact"
                                                 style="font-size:1.5em;">Add Contact </a>
                                             </div>  
                                            
                                            <div class="form-group has-feedback
                                            user_link_right_button ">
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                         <?php } }
										 else{
										 ?>
                                         <div class="building_records_main">
                                             <div  class="user_link_left_button">
                                                 <a href="<?php echo base_url(); ?>Contacts/" 
                                                 class="pictures_link radius8" title="New Contact"
                                                 style="font-size:1.5em;">Add Contact </a>
                                             </div>  
                                            
                                            <div class="form-group has-feedback
                                            user_link_right_button ">
                                             <span class='glyphicon glyphicon-ok form-control-feedback'></span>
                                            </div>
                                           </div>
                                         <?php
										 }
										 ?>  
                                         
                                         
                                           
                                           
                                        <br><br><br>
                                      
                                            
                                     
                                            <table id="grid1" width="100%"></table> 
                                           
                                        
                                          
                                         
                                        
                                            </div>

                                          
                                         
                                 
                                       
                                       
  
                                      <!--End of page container-->

     
         </div>                                        
     
         </div>
    </div>
</div> 
  

<script>
$(function () {
           
		    $("#grid1").igGrid({
                primaryKey: "contacts_id",
                margin:'20px',
				width: '100%',
				
                columns: [
                    { headerText: "Contacts ID", key: "contacts_id", dataType: "string", width: "15%", hidden: true },
					{ headerText: "Title", key: "contact_name", dataType: "string", width: "20%"},
					{ headerText: "Contact Name", key: "title", dataType: "string", width: "20%"},
					{ headerText: "Cell", key: "cell", dataType: "string", width: "20%"},
                  
 					{ headerText: "Action", key: "edit", dataType: "string", width: "10%",unbound:true,
					template: "<a class='fancybox fancybox.ajax'  href='<?=base_url();?>Contacts/update?id=${contacts_id}'><img src='<?=base_url();?>static/images/icons/edit.gif'/></a>" },
					
				
                
                ],
                autofitLastColumn: false,
                autoGenerateColumns: false,
                dataSource: contact_data,
                responseDataKey: "results",
                autoCommit: true,
               features: [
                   
					{
                        name: "Sorting",
                        sortingDialogContainment: "window"
                    },
                    {
                        name: "Filtering",
                        type: "local",
                        columnSettings: [
                            {
                                columnKey: "edit",
                                allowFiltering: false
                            }
                        ] 
                      
                     },
                  {
                        name: "Paging",
                        pageSize: 10
                    },
              
			        {
                        name: "Resizing"
                    },
                   
                ]
            });
        });	
</script>
</body>
</html>