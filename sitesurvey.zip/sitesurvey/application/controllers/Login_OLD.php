<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()  {
        parent:: __construct();
  
      $this->load->helper(array('url'));
  
    }
      
 
	 
	public function index(){
     	$this->load->template('login_information');
	}
	
	public function logininfo(){
     
	   $this->load->library('session');	  // Load the Session Library..
	   $this->load->model('Authenticate');  // Load the Model Library..
	 
	   
	     
	   $user_data['result'] =  $this->Authenticate->checkLogin($this->input->post('email'),$this->input->post('password'));
	
	    
		
	  
	  
	  if($user_data['result'])
	  {
	       $this->session->set_userdata($user_data);  // Loading Data into Session
	       redirect(base_url()."Login/home");
		  
	  }
     else
	 {
		 $this->session->set_flashdata('Error', 'Invalid Email or Password!');
	     redirect(base_url()."Login/index");	 
	 }
 	}
   public function home(){
	
	   $data['page_name'] = "dashboard";
	   $this->load->template('dashboard',$data);
	
   }
   
   public function logout(){
	 
	  $this->session->unset_userdata("result"); 
	  $this->session->sess_destroy();
	  redirect(base_url());
   }
   
   public function insertBuilding(){
     
	 $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Locationrecordsdata');
	 
	   $buidling_information  = $this->input->post('n_building_address');
	   if(strpos($buidling_information, '/')){
	   $lon_lat = explode("/",$buidling_information);
	   
	   $result['check_exist'] =  $this->Locationrecordsdata->checkLatLng($lon_lat[0],$lon_lat[1]);
	   if($result['check_exist']){
			
			$this->session->set_flashdata('Error', 'This Building is Already Exist!');
		    redirect(base_url()."Login/Home");	
		}
	   else{
	   $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($lon_lat[0]).','.trim($lon_lat[1]).'&sensor=false';
	   $json = @file_get_contents($url);
	   $data=json_decode($json);
	   $status = $data->status;
	   if($status=="OK"){
		
		$result['insert_building_id'] =  $this->Locationrecordsdata->insertingBuilding($lon_lat[0],$lon_lat[1],
		$data->results[0]->formatted_address);
		
		if($result['insert_building_id']==1){
				$this->session->set_flashdata('Success', 'New Building Created Successfully.');
				redirect(base_url()."Login/Home",$result);
		}
		else{
				$this->session->set_flashdata('Error', 'Building is not Created, due to Internal Error !');
				redirect(base_url()."Login/Home");	 
		}
	   
      }
	  else{
	   $this->session->set_flashdata('Error', "No Address is Asscoiated with this Lattitude and Longitude");
	   redirect(base_url()."Login/Home");
	  }
     }
   }
    else{
	   $this->session->set_flashdata('Error', "Latitude and Longitude is not Formatted");
	   redirect(base_url()."Login/Home");
	  }
	 
   }
   
    public function searchExistingLocation(){
     
	 $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Locationrecordsdata');
	 
	   //$buidling_information  = $this->input->post('existing_location');
	   
	//	     $lon_lat = explode("/",$buidling_information);
		
		
	
		$user_data['search_building_result'] =  $this->Locationrecordsdata->searchLocation($this->input->post('existing_id'));
		
		if($user_data['search_building_result']!=0){
				$this->session->set_userdata($user_data); 
				$this->session->set_flashdata('Success', 'Building was found.');
				redirect(base_url()."Login/Home");
		}
		else{
				$this->session->set_flashdata('Error', 'Building was not found.');
				redirect(base_url()."Login/Home");	 
		}
	 
   }
   
 public function error(){
    
	 $this->load->library('session');	  // Load the Session Library..
	 $this->session->set_flashdata('Error', 'Please Select Some Building Before Proceeding.');
	 redirect(base_url()."Login/Home");
 }
 

 public function searchSuggestion() {
    $this->load->model("Locationrecordsdata");
		//$kode = $this->input->post('kode',TRUE); //variabel kunci yang di bawa dari input text id kode
    $query = $this->Locationrecordsdata->giveSuggestion(); //query model
    $data       =  array();
    foreach ($query as $d) {
    $data[]     = array(
    'label' =>$d->ss_address,
	'id' => $d->building_id
            );
        }
        echo json_encode($data);      //data array yang telah kota deklarasikan dibawa menggunakan json
 }
 public function currentLatLng(){
	 
	$ip  = !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
	$url = "http://freegeoip.net/json/$ip";
	$ch  = curl_init();

	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
	$data = curl_exec($ch);
	curl_close($ch);

	if ($data) {
		$location = json_decode($data);
	
		$lat = $location->latitude;
		$lon = $location->longitude;
	
		$sun_info = date_sun_info(time(), $lat, $lon);
		print_r($sun_info);
		echo $lat."/".$lon;
	}
 }
 function searchCurrent(){
    
	 $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Locationrecordsdata');
	 
	 $user_data['search_building_result'] =NULL;
	 $user_data['search_building_result'] =  $this->Locationrecordsdata->checkLatLng($this->input->get('lat'),$this->input->get('lng'));
	 
	 if($user_data['search_building_result']){
				$this->session->set_userdata($user_data); 
				$this->session->set_flashdata('Success', 'Building was found.');
				redirect(base_url()."Login/Home");
	 }
	else{
				$this->session->set_flashdata('Error', 'Building is not Exist on your Current Location.');
				redirect(base_url()."Login/Home");	 
	}
 
 }
 

 
}
 





 
