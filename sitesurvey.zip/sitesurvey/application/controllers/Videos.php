<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Videos extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
    public function __construct() { 
         parent::__construct(); 
         $this->load->helper('url'); 
    }
    public function index()
	{
		$this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Videosdata');  // Load the Model Library..
		  
		$retrieve_searched_data = $this->session->userdata('search_building_result');
     	
		$videos_list['list'] =$this->Videosdata->allVideos($retrieve_searched_data[0]['building_id']); 
		$videos_list['call_from'] = "videos";
		/*  if($this->input->post('status')==1){
		 
			  if($this->input->post('v_name')=="" || $this->input->post('file_link')=="" ||
				 $this->input->post('capture_date')=="" ||
				 $this->input->post('picture')==""){
				   $this->session->set_flashdata('Empty_Error', 'All Fields are Required (*).');
				   $videos_list['file_link'] = $this->input->post('file_link');
				   $videos_list['capture_date'] = $this->input->post('capture_date');
				   $videos_list['v_name'] = $this->input->post('v_name');
				   $videos_list['picture'] = $this->input->post('picture');
				 
			}
			
		 }
	*/	 
		 if($videos_list['list']==0){
		    	 $this->session->set_flashdata('Err', 'No Record was Found!');
	    }
		
		
		$this->load->template('videos_information',$videos_list);
	}
   public function do_upload() { 
        
		  $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Videosdata');  // Load the Model Library..
		 
		 $config['upload_path']   = './uploads/videos_image'; 
         $config['allowed_types'] = 'gif|jpg|png|jpeg'; 
         $config['max_size']      = 1000; 
         $config['max_width']     = 1024; 
         $config['max_height']    = 1000;  
         $this->load->library('upload', $config);
		 
		 $retrieve_searched_data = $this->session->userdata('search_building_result');
	     $retrieve_session = $this->session->userdata('result');
	   
			
         if ( ! $this->upload->do_upload('picture')) {
              $this->session->set_flashdata('Err', $this->upload->display_errors());
			  redirect(base_url()."Videos/index"); 
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data());
			
			 $config['image_library'] = 'gd2';
             $config['source_image'] = "./uploads/videos_image/".$data['upload_data']['file_name'];
			 $config['new_image'] = './uploads/videos_image/video_thumbnail/'.$data['upload_data']['file_name'];
			 $config['create_thumb'] = TRUE;
			 $config['maintain_ratio'] = TRUE;
			 $config['width']         = 75;
			 $config['height']       = 50;
			 $this->load->library('image_lib', $config);
			 $this->image_lib->resize();
			 if ( !$this->image_lib->resize()){
                   $this->session->set_flashdata('Err', $this->image_lib->display_errors());
				   redirect(base_url()."Videos/index");
			 }
			else{
			    $thumbnail_path = "uploads/videos_image/video_thumbnail/".
			    $data['upload_data']['raw_name'].'_thumb'.$data['upload_data']['file_ext']; 
			
				$videos['result'] =$this->Videosdata->insertingVideos($retrieve_searched_data[0]['building_id'],
				base_url()."uploads/videos_image/".$data['upload_data']['file_name'],
				$retrieve_session[0]['user_id'],$this->input->post('v_name'),
				$this->input->post('file_link'),date("Y-m-d",strtotime($this->input->post('capture_date'))),
				base_url().$thumbnail_path); 
				
				
				 if($videos['result']==1){
					$this->session->set_flashdata('Succ', 'One Record is Inserted Sucessfully.');
					redirect(base_url()."Videos/index");
				}
				else{
					$this->session->set_flashdata('Err', 'Record is not Inserted.');
					redirect(base_url()."Videos/index");
				}
		 }
         } 
      } 
   

	
}
 