<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Building extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
	 
	public function index()
	{     
	
	      $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Buildingdata');  // Load the Model Library..
		
		  $retrieve_searched_data = $this->session->userdata('search_building_result');
		  $retrieve_session = $this->session->userdata('result');
		  $retrieve_permission = $this->session->userdata('permission');
		  
		  $building_list['all_list'] =$this->Buildingdata->allBuildings($retrieve_session[0]['company_id'],"0"); 
	     if($building_list['all_list']==0){
		    	 $this->session->set_flashdata('Err', 'No Buildings are Available!');
	    }
		
		
		if($retrieve_session[0]["user_type"]=="2"){
		  if(sizeof($retrieve_permission)==0){
	          	$this->session->set_flashdata('Err', 'No Building Permission is given to you!');
	  	     }
		
		}
		  $this->load->template('building_information',$building_list);
    }
	public function searchBuilding(){
	
	      $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Buildingdata');  // Load the Model Library..
		
		  $retrieve_searched_data = $this->session->userdata('search_building_result');
		  $retrieve_session = $this->session->userdata('result');
		  $building_list['searched_text']= $this->input->post('search');
		  $building_list['all_list'] =$this->Buildingdata->searchBuildings($this->input->post('search'),
		  $retrieve_session[0]['company_id']); 
	     if($building_list['all_list']==0){
		    	 $this->session->set_flashdata('Err', 'No Record was Found!');
	    }
		
		 $this->load->template('building_information',$building_list);
	}
	
   public function searchExistingLocation(){
     
	 $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Locationrecordsdata');
	 
	   //$buidling_information  = $this->input->post('existing_location');
	   
	//	     $lon_lat = explode("/",$buidling_information);
		
		
	
		$user_data['search_building_result'] =  $this->Locationrecordsdata->searchLocation($this->input->get('building_id'));
		
		if($user_data['search_building_result']!=0){
				$this->session->set_userdata($user_data); 
				$this->session->set_flashdata('Success', 'Building was found.');
				redirect(base_url()."Building/");
		}
		else{
				$this->session->set_flashdata('Error', 'Building was not found.');
				redirect(base_url()."Building/");	 
		}
	 
   }	
	

 public function delete(){
	 
     $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Buildingdata');
    $building_data['trash'] =  $this->Buildingdata->trash($this->input->get('id'));
	 if($building_data['trash']){
				
				$this->session->set_flashdata('Succ', 'One Record Deleted Successfully.');
				redirect(base_url()."Building/");
		}
		else{
				$this->session->set_flashdata('Err', 'Record is not Deleted.');
				redirect(base_url()."Building/");	 
		}
 }
	
 
   public function DeletedBuildings(){
      $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Buildingdata');  // Load the Model Library..
		
		  $retrieve_searched_data = $this->session->userdata('search_building_result');
		  $retrieve_session = $this->session->userdata('result');
		  $retrieve_permission = $this->session->userdata('permission');
		  
		  $building_list['all_list'] =$this->Buildingdata->allBuildings($retrieve_session[0]['company_id'],"1"); 
	     if($building_list['all_list']==0){
		    	 $this->session->set_flashdata('Err', 'No Buildings to Show!');
	    }
		
		
		if($retrieve_session[0]["user_type"]=="2"){
		  if(sizeof($retrieve_permission)==0){
	          	$this->session->set_flashdata('Err', 'No Building Permission is given to you!');
	  	     }
		
		}
		  $this->load->template('trash_information',$building_list);
   
   }
   
public function restore(){
	 
     $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Buildingdata');
    $building_data['restore'] =  $this->Buildingdata->restore($this->input->get('id'));
	 if($building_data['restore']){
				
				$this->session->set_flashdata('Succ', 'Selected Record Restore Successfully.');
				redirect(base_url()."Building/DeletedBuildings");
		}
		else{
				$this->session->set_flashdata('Err', 'Record not restored.');
				redirect(base_url()."Building/DeletedBuildings");	 
		}
 }
	
}
 