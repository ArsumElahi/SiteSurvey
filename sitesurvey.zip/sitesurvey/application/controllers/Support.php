<?php
defined('BASEPATH') OR exit('No direct script access allowed');

define("ZDAPIKEY", "CRs8MKlgRvOfyOS88audYrFfEeiM08k6QPrYdWEx");
define("ZDUSER", "arsum_elahi21@yahoo.com");
define("ZDURL", "https://zemtechnologieshelp.zendesk.com/api/v2"); //replace abc with your domain name.


class Support extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
    public function index(){
		 
		   $this->load->library('session');	  // Load the Session Library..
	       $this->load->model('Supportdata');  // Load the Model Library..
		
     
     
	      $retrieve_session = $this->session->userdata('result');
		  
		  $tickets['all_tickets'] =$this->Supportdata->allTickets($retrieve_session[0]['user_id']); 
		  $data = array();
		  if($tickets['all_tickets']){
		     foreach ($tickets['all_tickets'] as $row){
				$data_array = $this->curlWrap("/tickets/".$row['ticket_id'].".json", '', "GET");
              
                $data_result['ticket_no']     = $data_array->ticket->id;
                $data_result['ticket_desc']   = $data_array->ticket->description;
                $data_result['ticket_status'] = $data_array->ticket->status;
             
			   $data[] = $data_result;
            }
		  }
		      if(sizeof($data)>0){
			     $ticket_result['result'] =  $data;
				 $ticket_result['call_from'] =  "support";
			    // print_r($ticket_result['result']);
				 $this->load->template("support_information",$ticket_result);
			  }
		    else{
		  	     $this->session->set_flashdata('Err', 'No ticket is Created Yet!');
				 $ticket_result['call_from'] =  "support";
				 $this->load->template("support_information",$ticket_result);
			 
			  }
		    
			  
   	
			
		
	}
	function curlWrap($url, $json, $action)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_MAXREDIRS, 10 );
		curl_setopt($ch, CURLOPT_URL, ZDURL.$url);
		curl_setopt($ch, CURLOPT_USERPWD, ZDUSER."/token:".ZDAPIKEY);
		//curl_setopt($ch, CURLOPT_CAINFO, "C:/cacert.pem"); //I downloaded the certifcate to this location for CURL. 
	
		switch($action){
			case "POST":
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
				break;
			case "GET":
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
				break;
			case "PUT":
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
				curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
				break;
			case "DELETE":
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
				break;
			default:
				break;
		}
	 
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
		curl_setopt($ch, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		$output = curl_exec($ch);
		if(curl_error($ch)){
		    $this->session->set_flashdata('Err', 'Ooops! We are unable to connect to the Support, Please Try Again Later');
			redirect(base_url()."Support/index");
		}
		curl_close($ch);
		$decoded = json_decode($output);
		return $decoded;
	}
 
   function createTicket(){
          $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Supportdata');  // Load the Model Library..
		
     
		  $retrieve_session = $this->session->userdata('result');

			$z_subject = "New Request From Site Survey User";
			$z_description = $this->input->post("ContactComment");
			$sender_name = $retrieve_session[0]['user_name'];
			$sender_email = $retrieve_session[0]['user_email'];
			//echo $retrieve_session[0]['user_email'];
			$arr = array(
				"z_subject" => $z_subject,
				"z_description" => $z_description,
				"z_name" => $sender_name,
				"z_requester" => $sender_email,
				"priority" => "normal"
			);
		
			$create = json_encode(array('ticket' => array('priority' => $arr['priority'],
			'subject' => $arr['z_subject'], 'description' => $arr['z_description'], 
			'requester' => array('name' => $arr['z_name'], 'email' => $arr['z_requester']))), 
			JSON_FORCE_OBJECT);
		
			$data = $this->curlWrap("/tickets", $create, "POST");
		
			if($data->ticket->id!=""){
			  $result['new_ticket'] = $this->Supportdata->insertingTicketData($retrieve_session[0]['user_id'],
			  $data->ticket->id);
			  
			  if($result['new_ticket']==1){
			     $this->session->set_flashdata('Succ', 'Ticket is Open Successfully, Your Ticket No is: '.$data->ticket->id);
			     redirect(base_url()."Support/index");
			  }  
			  else{
			  
			      $this->session->set_flashdata('Err', 'Ticket is not Created');
			      redirect(base_url()."Support/index");
			  }
			}
	}
	function creatingVoiceTicket(){
	   
	$create = json_encode(array("display_to_agent" => 4 ,'ticket' => array('via_id' => 45,
			'subject' => "My printer is on fire!", 
			'comment' => array('body' => "The smoke is very colorful."),
			'priority'=> "urgent")), 
			JSON_FORCE_OBJECT);
		
		
			$data = $this->curlWrap("/channels/voice/tickets.json", $create, "POST");
			
			print_r($data);
	}

}
 