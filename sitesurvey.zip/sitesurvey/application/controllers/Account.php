<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
	 
	public function index()
	{
     	$this->load->template('signup_information');
	}
	
	public function newuser()
	{
       $this->load->library('session');	  // Load the Session Library..
	   $this->load->model('Authenticate');  // Load the Model Library..
	 
	   	   $data = array(
'user_name' =>     $this->input->post('username'),
'user_email' =>    $this->input->post('email'),
'user_password' => $this->input->post('password'),
'user_status' => "1");
	     
	   $result['insertion'] =  $this->Authenticate->signUp($data);
	 

	  
	  if($result['insertion']==true){
	   $this->session->set_flashdata('msg',"Account is Created Successfully");
	   redirect (base_url()."Login/index");
	  }
	  else{
//		  redirect (base_url()."Login/index");
	  }
	  
	 
 	}
 
  
   

	
}
 