<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()  {
        parent:: __construct();
  
      $this->load->helper(array('url'));
  
    }
      
 
	 
	public function index(){
     	$this->load->library('session');	  // Load the Session Library..
		
	
	    $retrieve_session = $this->session->userdata('result');
		if($retrieve_session[0]['user_id']!=""){
            redirect(base_url()."Login/home");
  
        }
		else{
		$this->load->template('login_information');
		}
		
	}
	
	public function logininfo(){
     
	   $this->load->library('session');	  // Load the Session Library..
	   $this->load->model('Authenticate');  // Load the Model Library..
	 
	   
	     
	   $user_data['result'] =  $this->Authenticate->checkLogin($this->input->post('email'),$this->input->post('password'));
	
	    
		
	  
	  
	  if($user_data['result'])
	  {
	       $this->session->set_userdata($user_data);  // Loading Data into Session
	       
		   
		 
		   
		   redirect(base_url()."Login/home");
		  
	  }
     else
	 {
		 $this->session->set_flashdata('Error', 'Invalid Email or Password!');
	     redirect(base_url()."Login/index");	 
	 }
 	}
   public function home(){
	    
		 $this->load->library('session');	  // Load the Session Library..
		 $this->load->model('Authenticate');  // Load the Model Library..
		 $this->session->unset_userdata("permission"); 
		 $retrieve_session = $this->session->userdata('result');
		 
	    if($retrieve_session[0]["user_type"]=="2"){
             $user_data['permission'] =  $this->Authenticate->gettingPermission($retrieve_session[0]["user_id"]);
		     if($user_data['permission']){
	          $this->session->set_userdata($user_data);  // Loading Data into Session
	  	     }
			 else{
			 	$this->session->set_flashdata('Error', 'No Building Permission is given to you!');
			 }
		}
	  
	   $data['page_name'] = "dashboard";
	   $this->load->template('dashboard',$data);
   }
   
   public function logout(){
	 
	  $this->session->unset_userdata("result"); 
	  $this->session->unset_userdata("permission"); 
	  $this->session->sess_destroy();
	  redirect(base_url());
   }
   
   public function insertBuilding(){
     
	 $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Locationrecordsdata');
	 
	   $retrieve_session = $this->session->userdata('result');
	   $buidling_information  = $this->input->post('n_building_address');
	   if(strpos($buidling_information, '/')){
	   $lon_lat = explode("/",$buidling_information);
	   
	   $result['check_exist'] =  $this->Locationrecordsdata->checkLatLng(substr($lon_lat[0],0,4),substr($lon_lat[1],0,4));
	 /*  if($result['check_exist']){
			
			$this->session->set_flashdata('Error', 'This Building is Already Exist!');
		    redirect(base_url()."Login/Home");	
		}
	   else{
	  */
	   $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($lon_lat[0]).','.trim($lon_lat[1]).'&sensor=false';
	   $json = @file_get_contents($url);
	   $data=json_decode($json);
	   $status = $data->status;
	   if($status=="OK"){
		 
  		$result['insert_building_id'] =  $this->Locationrecordsdata->insertingBuilding(substr($lon_lat[0],0,4),
		substr($lon_lat[1],0,4),
		$data->results[0]->formatted_address,$retrieve_session[0]['company_id']
		,$data->results[0]->address_components[0]->long_name,$data->results[0]->address_components[1]->long_name,
		$data->results[0]->address_components[3]->long_name,$retrieve_session[0]['user_id']);
		
		if($result['insert_building_id']==1){
				$this->session->set_flashdata('Success', 'New Building Created Successfully.');
				redirect(base_url()."Login/Home",$result);
		}
		else{
				$this->session->set_flashdata('Error', 'Building is not Created, due to Internal Error !');
				redirect(base_url()."Login/Home");	 
		}
	   
      }
	  else{
	   $this->session->set_flashdata('Error', "No Address is Asscoiated with this Lattitude and Longitude");
	   redirect(base_url()."Login/Home");
	  }
   //  }
   }
    else{
	     $prepAddr = str_replace(' ','+',$buidling_information);
         $geocode=file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$prepAddr.'&sensor=false');
         $data= json_decode($geocode);
       	 $status = $data->status;
			 if($status=="OK"){
				  $latitude = $data->results[0]->geometry->location->lat;
				  $longitude = $data->results[0]->geometry->location->lng;
				  $result['check_exist'] =  $this->Locationrecordsdata->checkLatLng(substr($latitude,0,4),substr($longitude,0,4));
				/*	if($result['check_exist']){
						
						$this->session->set_flashdata('Error', 'This Building is Already Exist!');
						redirect(base_url()."Login/Home");	
					}
					else{
				*/			  
						$result['insert_building_id'] =  $this->Locationrecordsdata->insertingBuilding(substr($latitude,0,4),
						substr($longitude,0,4),
						 $data->results[0]->formatted_address,$retrieve_session[0]['company_id']
						,$data->results[0]->address_components[0]->long_name,$data->results[0]->address_components[1]->long_name,
						$data->results[0]->address_components[3]->long_name,$retrieve_session[0]['user_id']);
						
						if($result['insert_building_id']==1){
								$this->session->set_flashdata('Success', 'New Building Created Successfully.');
								redirect(base_url()."Login/Home",$result);
						}
						else{
								$this->session->set_flashdata('Error', 'Building is not Created, due to Internal Error !');
								redirect(base_url()."Login/Home");	 
						}
				//  }
		  }
		  else{
		   $this->session->set_flashdata('Error', "No Latitude and Longitude is Asscoiated with this Address");
		   redirect(base_url()."Login/Home");
		  }
	   }
	 
   }
   
    public function searchExistingLocation(){
     
	 $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Locationrecordsdata');
	 
	   //$buidling_information  = $this->input->post('existing_location');
	   
	//	     $lon_lat = explode("/",$buidling_information);
		
		
	
		$user_data['search_building_result'] =  $this->Locationrecordsdata->searchLocation($this->input->post('existing_id'));
		
		if($user_data['search_building_result']!=0){
				$this->session->set_userdata($user_data); 
				$this->session->set_flashdata('Success', 'Building was found.');
				redirect(base_url()."Login/Home");
		}
		else{
				$this->session->set_flashdata('Error', 'Building was not found.');
				redirect(base_url()."Login/Home");	 
		}
	 
   }
   
 public function error(){
    
	 $this->load->library('session');	  // Load the Session Library..
	 $this->session->set_flashdata('Error', 'Please Select Some Building Before Proceeding.');
	 redirect(base_url()."Login/Home");
 }
 

 public function searchSuggestion() {
	$this->load->library('session');	  // Load the Session Library..
    $this->load->model("Locationrecordsdata");
	$retrieve_session = $this->session->userdata('result');
	
	if($retrieve_session[0]['user_type']=="2" ){
	
	$query = $this->Locationrecordsdata->givePermissionSuggestion($this->input->get("existing_location"),
	$retrieve_session[0]['company_id'],$retrieve_session[0]['user_id']);   
	}
	else if($retrieve_session[0]['user_type']=="3"){
	 $query = $this->Locationrecordsdata->giveSuggestion_contractor($this->input->get("existing_location"),
	$retrieve_session[0]['company_id'],$retrieve_session[0]['user_id']);}
	else{
	$query = $this->Locationrecordsdata->giveSuggestion($this->input->get("existing_location"),$retrieve_session[0]['company_id']);    }
	
	
    $data       =  array();
    foreach ($query as $d) {
    $data[]     = array(
    'label' =>$d->ss_address,
	'id' => $d->building_id
            );
        }
        echo json_encode($data);      
 }
 public function currentLatLng(){
	 
	$ip  = !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
	$url = "http://freegeoip.net/json/$ip";
	$ch  = curl_init();

	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
	$data = curl_exec($ch);
	curl_close($ch);

	if ($data) {
		$location = json_decode($data);
	
		$lat = $location->latitude;
		$lon = $location->longitude;
	
		$sun_info = date_sun_info(time(), $lat, $lon);
		print_r($sun_info);
		echo $lat."/".$lon;
	}
 }
 function searchCurrent(){
    
	 $this->load->library('session');	  // Load the Session Library..
     $this->load->model('Locationrecordsdata');
	 
	 $user_data['search_building_result'] =NULL;
	 $user_data['search_building_result'] =  $this->Locationrecordsdata->checkLatLng($this->input->get('lat'),$this->input->get('lng'));
	 
	 if($user_data['search_building_result']){
				$this->session->set_userdata($user_data); 
				$this->session->set_flashdata('Success', 'Building was found.');
				redirect(base_url()."Login/Home");
	 }
	else{
				$this->session->set_flashdata('Error', 'Building is not Exist on your Current Location.');
				redirect(base_url()."Login/Home");	 
	}
 
 }
 

 
}
 





 
