<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Records extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
	 
	public function index()
	{  
	
	    $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Locationrecordsdata');  // Load the Model Library..
        $retrieve_searched_data = $this->session->userdata('search_building_result');
	    
		$building_record['check_exist'] =$this->Locationrecordsdata->checkBuildingExist
		($retrieve_searched_data[0]['building_id']); 
	    if($building_record['check_exist']==0){
		    	 $this->session->set_flashdata('Err', 'Building Detail was not Found!');
	             $this->load->template('buildingRecords_information');
		}
		else{
		      $this->session->set_flashdata('Succ', 'Data Retrieve Successfully!');
	          $this->load->template('buildingRecords_information',$building_record);
			  
		}
		
	 	
	}
	
	 public function creatingBuilding(){
        $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Locationrecordsdata');  // Load the Model Library..
     	
		
		$retrieve_searched_data = $this->session->userdata('search_building_result');
		$retrieve_session = $this->session->userdata('result');
	    /*  
		  if($this->input->get('id')){
			  
			   $data = array(
				'msa_name' =>                     $this->input->post('msa_name'),
				'latitude' =>                     $this->input->post('latitude'),
				'longitude' =>                    $this->input->post('longitude'),
				'building_cat' =>                 $this->input->post('b_category'),
				'building_id' =>                  $retrieve_searched_data[0]['id_building'],
				'central_office' =>               $this->input->post('c_office'),
				'fiber_status' =>                 $this->input->post('f_status'),
				'fiber_ownership' =>              $this->input->post('f_ownership'),
				'connectivity_type' =>            $this->input->post('c_type'),
				'access_medium' =>                $this->input->post('a_medium'),
				'NPA/NXX' =>                      $this->input->post('npa'),
				'lata' =>                         $this->input->post('lata'),
				'building_access_agreement' =>    $this->input->post('b_a_a'),
				'date' =>                         date("Y-m-d",strtotime($this->input->post('date'))),
				'cost' =>                         $this->input->post('cost'),
				'updated_dateTime' =>			 date("Y-m-d h:i:s"),
				'last_updated_by' =>              $retrieve_session[0]['user_id']);
				
				$result['update_building'] =  $this->Location_RecordsData->update_BuildingDetail($data,$this->input->get('id'));
		
				if($result['update_building']==1){
				    $this->session->set_flashdata('Success', 'One Record was Updated Successfully.');
					redirect(base_url()."Records/listBuilding");
				}
				else{
				$this->session->set_flashdata('Error', 'Record is not Updated, Due to Internal Error !');
				redirect(base_url()."Records/listBuilding");	 
				}
		  }
		  else{
			  */
		$data = array(
			'msa_name' =>                     $this->input->post('msa_name'),
			'building_cat' =>                 $this->input->post('b_category'),
			'building_id' =>                  $retrieve_searched_data[0]['building_id'],
			'central_office' =>               $this->input->post('c_office'),
			'fiber_status' =>                 $this->input->post('f_status'),
			'fiber_ownership' =>              $this->input->post('f_ownership'),
			'connectivity_type' =>            $this->input->post('c_type'),
			'access_medium' =>                $this->input->post('a_medium'),
			'NPA/NXX' =>                      $this->input->post('npa'),
			'lata' =>                         $this->input->post('lata'),
			'building_access_agreement' =>    $this->input->post('b_a_a'),
			'date' =>                         date("Y-m-d",strtotime($this->input->post('date'))),
			'building_status' =>              "1",
			'cost' =>                         $this->input->post('cost'),
			'created_by' =>                   $retrieve_session[0]['user_id'],
			'company_id' =>                   $retrieve_session[0]['company_id'],
			'fiber_contractor' =>             $this->input->post('fiber_contractor'),
			'lateral_count' =>                $this->input->post('lat_count'),
			'lateral_cost' =>                 $this->input->post('lat_cost'),
			'lateral_distance' =>             $this->input->post('lat_distance'));
			  
		 $result['new_building'] =  $this->Locationrecordsdata->insertingBuildingDetail($data);
		
		if($result['new_building']==1){
		    $this->session->set_flashdata('Success1', 'Data Inserted Successfully!');
			redirect(base_url()."Records/index");
		}
		else{
			$this->session->set_flashdata('Error1', 'Building Detail is not Added. Please Check Database Connection!');
	        redirect(base_url()."Records/index");	 
		}
		
    //}
}

public function updatingBuilding(){
        $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Locationrecordsdata');  // Load the Model Library..
     	
		
		$retrieve_searched_data = $this->session->userdata('search_building_result');
		$retrieve_session = $this->session->userdata('result');
	   
	    $data = array(
			'msa_name' =>                     $this->input->post('msa_name'),
			'building_cat' =>                 $this->input->post('b_category'),
			'central_office' =>               $this->input->post('c_office'),
			'fiber_status' =>                 $this->input->post('f_status'),
			'fiber_ownership' =>              $this->input->post('f_ownership'),
			'connectivity_type' =>            $this->input->post('c_type'),
			'access_medium' =>                $this->input->post('a_medium'),
			'NPA/NXX' =>                      $this->input->post('npa'),
			'lata' =>                         $this->input->post('lata'),
			'building_access_agreement' =>    $this->input->post('b_a_a'),
			'date' =>                         date("Y-m-d",strtotime($this->input->post('date'))),
			'building_status' =>              "1",
			'cost' =>                         $this->input->post('cost'),
			'last_updated_by' =>              $retrieve_session[0]['user_id'],
			'updated_dateTime' =>			 date("Y-m-d h:i:s"),
			'fiber_contractor' =>             $this->input->post('fiber_contractor'),
			'lateral_count' =>                $this->input->post('lat_count'),
			'lateral_cost' =>                 $this->input->post('lat_cost'),
			'lateral_distance' =>             $this->input->post('lat_distance'));
			  
		 $result['update_building'] =  $this->Locationrecordsdata->update_BuildingDetail($data,
		 $retrieve_searched_data[0]['building_id']);
		
		if($result['update_building']==1){
		    $this->session->set_flashdata('Success1', 'Data Updated Successfully!');
			redirect(base_url()."Records/index");
		}
		else{
			$this->session->set_flashdata('Error1', 'Building Detail is not Updated. Please Check Database Connection!');
	        redirect(base_url()."Records/index");	 
		}
		
    //}
}
	
	 public function listBuilding(){
	 
	    $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Locationrecordsdata');  // Load the Model Library..
	   
	   
	    $retrieve_session = $this->session->userdata('result');
		
		$records_list['records_list'] =$this->Locationrecordsdata->allBuilding($retrieve_session[0]['company_id']); 
	  
	   if($records_list['records_list']==0){
		    	 $this->session->set_flashdata('Error', 'No Record Was Found!');
	    }
		
	   $this->load->template('buildingRecords_listView',$records_list);
	 
	 
	 }
	
	 public function edit(){
	    
		$this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Locationrecordsdata');  // Load the Model Library..
		
		
		$data['buildingdetail_id'] =$this->input->get('id');
		$data['buildingdetail'] = $this->Locationrecordsdata->edit_BuildingDetail($this->input->get('id'));
		
		$this->load->template('buildingRecords_information',$data);
	
	 }
	
   

	
}
 