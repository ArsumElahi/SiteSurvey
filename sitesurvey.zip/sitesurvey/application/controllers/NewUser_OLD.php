<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class NewUser extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
	 
	public function index()
	{
      
     	$this->load->template('newuser_information');
	}
	
	
	 public function CreatingUser(){
        $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Authenticate');  // Load the Model Library..
     	
	//	 $this->Authenticate->insertingUser($this->input->post('email'),$this->input->post('password'));
		
		$data = array(
		'user_name' =>     $this->input->post('username'),
		'user_email' =>    $this->input->post('email'),
		'user_password' => $this->input->post('password'),
		'user_status' => "1",
		'user_type' =>"2");
		  
		   $retrieve_session = $this->session->userdata('result');
		   $result['new_user'] =  $this->Authenticate->insertingUser($data, $retrieve_session[0]['company_id']);
		if($result['new_user']==1){
		    redirect(base_url()."NewUser/listUser");
		}
		else{
			$this->session->set_flashdata('Error', 'User is not Created. Please Check Database Connection!');
	        redirect(base_url()."NewUser/");	 
		}
			  
		
	}
	
	
	 public function listUser(){
	 
	    $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Authenticate');  // Load the Model Library..
	   
	   
	    $retrieve_session = $this->session->userdata('result');
		
		$member_list['users_list'] =$this->Authenticate->allUser($retrieve_session[0]['company_id']); 
	  
	   if($member_list['users_list']==0){
		    	 $this->session->set_flashdata('Error', 'No Record Was Found!');
	    }
		
	 
	  $this->load->template('listuser_information',$member_list);
	 
	 }
   

	
}
 