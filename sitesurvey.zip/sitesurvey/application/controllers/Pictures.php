<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pictures extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
    public function __construct() { 
         parent::__construct(); 
         $this->load->helper('url'); 
    }
	 
	public function index()
	{
       $this->load->library('session');	  // Load the Session Library..
	   $this->load->model('Picturesdata');  // Load the Model Library..
     	
	   $retrieve_searched_data = $this->session->userdata('search_building_result');
	   
	   $pictures['link']      = $this->Picturesdata->allPictures($retrieve_searched_data[0]['building_id']); 
	   $pictures['category'] = $this->Picturesdata->allCategory();
	   $pictures['call_from'] = "picture";
	     
		/* if($this->input->post('status')){
		 
			  if($this->input->post('p_name')=="" || $this->input->post('file_link')=="" ||
				 $this->input->post('capture_date')=="" || $this->input->post('cat_id')=="" ||
				 $this->input->post('picture')==""){
				   $this->session->set_flashdata('Empty_Error', 'All Fields are Required (*).');
				   $pictures['file_link'] = $this->input->post('file_link');
				   $pictures['capture_date'] = $this->input->post('capture_date');
				   $pictures['cat_id'] = $this->input->post('cat_id');
				   $pictures['p_name'] = $this->input->post('p_name');
				   $pictures['picture'] = $this->input->post('picture');
				 
			}
		 }
		*/ 
		 if($pictures['link']==0){
		    	 $this->session->set_flashdata('Err', 'No Record was Found!');
	    
		 }
	      $this->load->template('pictures_information',$pictures);
		 
	
	}
	
	public function do_upload() { 
        
		  $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Picturesdata');  // Load the Model Library..
		 
		 $config['upload_path']   = './uploads/pictures'; 
         $config['allowed_types'] = 'gif|jpg|png|jpeg'; 
         $config['max_size']      = 1000; 
         $config['max_width']     = 1024; 
         $config['max_height']    = 1000;  
         $this->load->library('upload', $config);
		 
		 $retrieve_searched_data = $this->session->userdata('search_building_result');
	     $retrieve_session = $this->session->userdata('result');
	    
		 if ( ! $this->upload->do_upload('picture')) {
              $this->session->set_flashdata('Err', $this->upload->display_errors());
			  redirect(base_url()."Pictures/index");
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data());
			
			 $config['image_library'] = 'gd2';
             $config['source_image'] = "./uploads/pictures/".$data['upload_data']['file_name'];
			 $config['new_image'] = './uploads/pictures/pictures_thumbnail/'.$data['upload_data']['file_name'];
			 $config['create_thumb'] = TRUE;
			 $config['maintain_ratio'] = TRUE;
			 $config['width']         = 75;
			 $config['height']       = 50;
			 $this->load->library('image_lib', $config);
			 $this->image_lib->resize();
			 if ( !$this->image_lib->resize()){
                   $this->session->set_flashdata('Err', $this->image_lib->display_errors());
				   redirect(base_url()."Pictures/index");
			 }
			else{ 
		
		    
			$thumbnail_path = "uploads/pictures/pictures_thumbnail/".
			$data['upload_data']['raw_name'].'_thumb'.$data['upload_data']['file_ext'];
			
			$pictures['result'] =$this->Picturesdata->insertingPictures($retrieve_searched_data[0]['building_id'],
			base_url()."uploads/pictures/".$data['upload_data']['file_name'],
			$retrieve_session[0]['user_id'],$this->input->post('p_name'),
			$this->input->post('file_link'),date("Y-m-d",strtotime($this->input->post('capture_date'))),
			$this->input->post('cat_id'),base_url().$thumbnail_path); 
			
			
			 if($pictures['result']==1){
	   	        $this->session->set_flashdata('Succ', 'One Record is Inserted Sucessfully.');
		        redirect(base_url()."Pictures/index");
	        }
			else{
			    $this->session->set_flashdata('Err', 'Record is not Inserted.');
		        redirect(base_url()."Pictures/index");
			}
		  }
         } 
    
	  } 
   
 
}
 