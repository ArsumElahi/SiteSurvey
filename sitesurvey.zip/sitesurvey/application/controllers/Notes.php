<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notes extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
	 
	public function index()
	{
       $this->load->library('session');	  // Load the Session Library..
	   $this->load->model('Notesdata');  // Load the Model Library..
	
	   $retrieve_searched_data = $this->session->userdata('search_building_result');
	
	   $notes['all_list'] =$this->Notesdata->allNotes($retrieve_searched_data[0]['building_id']); 
	   
	     if($notes['all_list']==0){
		    	 $this->session->set_flashdata('Err', 'No Notes are Available of Searched Building!');
	    }
	
		 $this->load->template('notes_information',$notes);
	}
	
	public function insertNotes(){
	   
	   $this->load->library('session');	  // Load the Session Library..
	   $this->load->model('Notesdata');  // Load the Model Library..
	
	  $retrieve_searched_data = $this->session->userdata('search_building_result');
	  $retrieve_session = $this->session->userdata('result');
	  if($this->input->post('building_notes')!=""){
	  $notes['result'] =$this->Notesdata->insertingNotes($retrieve_searched_data[0]['building_id'],
	  $this->input->post('building_notes'),$retrieve_session[0]['user_id']);
	  if($notes['result']==1){
	   	    $this->session->set_flashdata('Succ', 'Building Notes are Added Successfully.');
		    redirect(base_url()."Notes/index");
	  }
	  else{
	        $this->session->set_flashdata('Err', 'Building Notes are not Added, due to Internal Error.');
	        $this->load->template('notes_information');
	  }
	}
	else{
		redirect(base_url()."Notes/index");
	}
	}
	
 
   
   

	
}
 