<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attachment extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
    public function __construct() { 
         parent::__construct(); 
         $this->load->helper('url'); 
    }
	 
	public function index(){
      
      	  $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Attachmentdata');  // Load the Model Library..
		
		  $retrieve_searched_data = $this->session->userdata('search_building_result');
		  
		  $attachment['all_list'] =$this->Attachmentdata->allAttachments($retrieve_searched_data[0]['building_id']); 
	      $attachment['call_from'] = "attachment";
		/* if($this->input->post('status')==1 || $this->input->post('status')==2){
		 
			  if($this->input->post('p_name')=="" || $this->input->post('file_link')=="" ||
				 $this->input->post('capture_date')=="" || 
				 $this->input->post('picture')==""){
				   $this->session->set_flashdata('Empty_Error', 'All Fields are Required (*).');
				   $attachment['file_link'] = $this->input->post('file_link');
				   $attachment['capture_date'] = $this->input->post('capture_date');
				   $attachment['cat_id'] = $this->input->post('cat_id');
				   $attachment['p_name'] = $this->input->post('p_name');
				   $attachment['picture'] = $this->input->post('picture');
				   $attachment['status']= $this->input->post('status');
				 
			}
		 }
		 */
		 if($attachment['all_list']==0){
		    	 $this->session->set_flashdata('Err', 'No Attachments are Available of Searched Building!');
	    }
		
		$this->load->template('attachment_information',$attachment);
		  
		
	}
	
	public function attachedInfo(){
		
		  $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Attachmentdata');  // Load the Model Library..
		  
		  $retrieve_searched_data = $this->session->userdata('search_building_result');
		  $retrieve_session = $this->session->userdata('result');

			 $config['upload_path']   = './uploads/attachments'; 
			 $config['allowed_types'] = 'gif|jpg|png|jpeg'; 
			 $config['max_size']      = 1000; 
			 $config['max_width']     = 1024; 
			 $config['max_height']    = 1000;  
			 $this->load->library('upload', $config);
			 
	     if ( ! $this->upload->do_upload('picture')) {
              $this->session->set_flashdata('Err', $this->upload->display_errors());
			  redirect(base_url()."Attachment/index");
          }
		  else{
		     $attachment = array('upload_data' => $this->upload->data());
			 
			     $config['image_library'] = 'gd2';
				 $config['source_image'] = "./uploads/attachments/".$attachment['upload_data']['file_name'];
				 $config['new_image'] = './uploads/attachments/thumbnails/'.$attachment['upload_data']['file_name'];
				 $config['create_thumb'] = TRUE;
				 $config['maintain_ratio'] = TRUE;
				 $config['width']         = 75;
				 $config['height']       = 50;
				 $this->load->library('image_lib', $config);
				 $this->image_lib->resize();
			 
			 if ( !$this->image_lib->resize()){
                   $this->session->set_flashdata('Err', $this->image_lib->display_errors());
				   redirect(base_url()."Attachment/index");
			 }
			 else{
			 
			    $thumbnail_path = "uploads/attachments/thumbnails/".
			    $attachment['upload_data']['raw_name'].'_thumb'.$attachment['upload_data']['file_ext']; 
			  $data = array(
				'building_id' =>                     $retrieve_searched_data[0]['building_id'],
				'attachment_category' =>             $this->input->post('attachment_category') ,
				'user_id' =>                         $retrieve_session[0]['user_id'],
				'attachment_name' =>                 $this->input->post('p_name'),
				'attachment_link' =>                 $this->input->post('file_link'),
				'capture_date' =>                    date("Y-m-d",strtotime($this->input->post('capture_date'))),
				'attachment_path' =>                 base_url()."uploads/attachments/".$attachment['upload_data']['file_name'],
				'attachment_thumbnail' =>            base_url().$thumbnail_path );
				
				$result['attachment_data'] =  $this->Attachmentdata->insertingAttachment($data);
			
			if($result['attachment_data']==1){
			 	$this->session->set_flashdata('Succ', 'Data Inserted Successfully!');
				redirect(base_url()."Attachment/index");
			}
			else{
				$this->session->set_flashdata('Err', 'Data is not Inserted. Please Check Database Connection!');
				redirect(base_url()."Attachment/index");	 
			}
	     }
	  }
	}
	
   

	
}
 