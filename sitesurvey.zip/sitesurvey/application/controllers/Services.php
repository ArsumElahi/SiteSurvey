<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Services extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
	 
	public function index(){
      
     	  $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Servicedata');  // Load the Model Library..

		  $retrieve_searched_data = $this->session->userdata('search_building_result');
		 // echo $retrieve_searched_data[0]['latitude'].$retrieve_searched_data[0]['longitude'];;
		  $service_checked['check_result'] =$this->Servicedata->CheckedServices($retrieve_searched_data[0]['building_id']); 
		  $service_checked['duplicates'] = $this->Servicedata->duplicatesServices($retrieve_searched_data[0]['latitude'],
		  $retrieve_searched_data[0]['longitude'],$retrieve_searched_data[0]['building_id']);
		  if($service_checked['duplicates']==0){
		     $this->session->set_flashdata('duplicates', 'No Services are Selected Yet!');
			  
		   }
		   else{
			  
			   $data = array();
		   for($i=0;$i<sizeof($service_checked['duplicates']);$i++){
			     
				$rows['records']=$this->Servicedata->CheckedServices($service_checked['duplicates'][$i]['building_id']); 
			   
		        if (sizeof($rows['records'])>1){
				    for($j=0;$j<sizeof($rows['records']);$j++){
					  $data_result['services_id']     =   $rows['records'][$j]['services_id'];
                      $data_result['building_id']     =   $rows['records'][$j]['building_id'];
                      $data_result['service_type']    =   $rows['records'][$j]['service_type'];
				      $data_result['service_value']   =   $rows['records'][$j]['service_value'];
					
					  $data[] = $data_result;
					}
				}
				else{
				  $data_result['services_id']     =   $rows['records'][0]['services_id'];
                  $data_result['building_id']     =   $rows['records'][0]['building_id'];
                  $data_result['service_type']    =   $rows['records'][0]['service_type'];
				  $data_result['service_value']   =   $rows['records'][0]['service_value'];
           
				}
			
			   $data[] = $data_result;
			   
			  }
			 // print_r($rows['records']);
				$service_checked['get_result'] = $data;
		   }
	
	//	print_r($service_checked['get_result']);
		  if($service_checked['check_result']==0){
		    	 $this->session->set_flashdata('Err', 'No Services are Selected Yet!');
	     }
		 $this->load->template('services_information',$service_checked);
	}
	
	public function servicesCheck(){
		
		  $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Servicedata');  // Load the Model Library..
		  
		  $retrieve_searched_data = $this->session->userdata('search_building_result');
		  
		  if($this->input->get('delete')==1){
		    $service_checked['result'] = $this->Servicedata->deletingServices($retrieve_searched_data[0]['building_id'],
		    $this->input->get('type'),$this->input->get('value')); 
		    if($this->input->get('date')==1){
			
			$service_checked['result'] =$this->Servicedata->insertingServices($retrieve_searched_data[0]['building_id'],
		    $this->input->get('type'),$this->input->get('value')); 
			}
		 
		  }
		  else{
		  $service_checked['result'] =$this->Servicedata->insertingServices($retrieve_searched_data[0]['building_id'],
		  $this->input->get('type'),$this->input->get('value')); 
		  }
		  
		
	}
		public function servicesCheck1(){
		
		  $this->load->library('session');	  // Load the Session Library..
	      $this->load->model('Servicedata');  // Load the Model Library..
		  
		  $retrieve_searched_data = $this->session->userdata('search_building_result');
		  
		  if($this->input->get('delete')==1){
		    $service_checked['result'] = $this->Servicedata->deletingServices($this->input->get('building'),
		    $this->input->get('type'),$this->input->get('value')); 
		    if($this->input->get('date')==1){
			
			$service_checked['result'] =$this->Servicedata->insertingServices($this->input->get('building'),
		    $this->input->get('type'),$this->input->get('value')); 
			}
		 
		  }
		  else{
		  $service_checked['result'] =$this->Servicedata->insertingServices($this->input->get('building'),
		  $this->input->get('type'),$this->input->get('value')); 
		  }
		  
		
	}
	
	
   

	
}
 