<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class NewUser extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
	 
	public function index(){
		 $this->load->library('session');	  // Load the Session Library..
         $this->load->model('Authenticate');  // Load the Model Library..
		 
		 $retrieve_session = $this->session->userdata('result');
		 $result['list_buillding'] =  $this->Authenticate->building_list($retrieve_session[0]['company_id']);
   	    if($result['list_buillding']==0){
		  
		  $this->session->set_flashdata('Err', 'No Buidling is Available!');
		  
		}
	    
	   	$this->load->template('newuser_information',$result);
	}
     
		
	
	
	 public function CreatingUser(){
        $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Authenticate');  // Load the Model Library..
		
	//	 $this->Authenticate->insertingUser($this->input->post('email'),$this->input->post('password'));
		$result['check_email'] =  $this->Authenticate->checkEmailExist($this->input->post('email'));
		 if($result['check_email']){
		   $this->session->set_flashdata('Err', 'This Email is Already Exist!');
		   redirect(base_url()."NewUser/");	
		 }
	    else{	
		$data = array(
		'user_name' =>     $this->input->post('username'),
		'user_email' =>    $this->input->post('email'),
		'user_password' => $this->input->post('password'),
		'user_status' => "1",
		'user_type' =>     $this->input->post('user_cat_id'));
		  
		   $retrieve_session = $this->session->userdata('result');
		   $result['user'] =  $this->Authenticate->insertingUser($data, $retrieve_session[0]['company_id']);
		  
		if($result['user']>0){
		  if($this->input->post('user_cat_id')==2){ 
		 
		   foreach($this->input->post("building_id") as $building){ 
		  
			 	if( $this->input->post("visible_".$building) == "1"){
				  $result['new_user'] =  $this->Authenticate->insertingPermission("1",$result['user'],$building);
				}
			  if($this->input->post("edit_".$building) =="2"){
				  $result['new_user'] =  $this->Authenticate->insertingPermission("2",$result['user'],$building);
			   }
			
		  
		   }
		    if($result['user']>0){
			  $this->session->set_flashdata('Succ', 'New User is Created Successfully!');
			  redirect(base_url()."NewUser/listUser");	
			}
		  }
		 else{
            $this->session->set_flashdata('Succ', 'New User is Created Successfully!');
		   //  $this->session->set_flashdata('Err', 'Some Error is Occur while creating user, Please Try Again!');
		     redirect(base_url()."NewUser/listUser");	
		 }
		
		}
		else{
			$this->session->set_flashdata('Err', 'User is not Created. Please Check Database Connection!');
	        redirect(base_url()."NewUser/");	 
		}
	}
		
	}
	
	
	 public function listUser(){
	 
	    $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Authenticate');  // Load the Model Library..
	   
	   
	    $retrieve_session = $this->session->userdata('result');
		
	
		
		$member_list['users_list'] =$this->Authenticate->allUser
		($retrieve_session[0]['company_id'],$retrieve_session[0]['user_id']); 
		$member_list['call_from'] = "users";
	  
	   if($member_list['users_list']==0){
		    	 $this->session->set_flashdata('Err', 'No Record Was Found!');
	    }
		
	 
	  $this->load->template('listuser_information',$member_list);
	 
	 }
   
    public function signUp(){
		
		 $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Authenticate');  // Load the Model Library..
     	
		$result['check_exist'] =  $this->Authenticate->checkCompanyExist($this->input->post('company'));
		$result['check_email'] =  $this->Authenticate->checkEmailExist($this->input->post('email'));
		 if($result['check_email']){
		   $this->session->set_flashdata('Error', 'This Email is Already Exist!');
		   redirect(base_url()."Account/");	
		 }
		 else{
		  if($result['check_exist']){
			
			$this->session->set_flashdata('Error', 'This Company is Already Exist!');
		    redirect(base_url()."Account/");	
		}
		else{
		$data = array(
		'user_name' =>    $this->input->post('username'),
		'user_email' =>    $this->input->post('email'),
		'user_password' => $this->input->post('password'),
		'user_status' => "1",
		'user_type' =>"1");
		  
		 
		   $result['new_user'] =  $this->Authenticate->signUp($data, $this->input->post('company'));
		if($result['new_user']==1){
		    $this->session->set_flashdata('Success', 'New User Registered Successfully');
			redirect(base_url());
		}
		else{
			$this->session->set_flashdata('Error', 'User is not Created. Please Check Database Connection!');
	        redirect(base_url());	 
		}
	 }
	}
	}
	
}
 