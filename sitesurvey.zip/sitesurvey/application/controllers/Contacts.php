<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contacts extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
 
	 
	public function index(){
      
	   $this->load->template('buildingContacts_information');
	}
	
	public function creatingContact(){
        $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Contactsdata');  // Load the Model Library..
     	
	     $retrieve_searched_data = $this->session->userdata('search_building_result');
	     $retrieve_session = $this->session->userdata('result');
		
		$data = array(
		'contact_name' =>     $this->input->post('c_name'),
		'title' =>            $this->input->post('title'),
		'phone' =>            $this->input->post('phone'),
		'cell' =>             $this->input->post('landline'),
		'email' =>            $this->input->post('email'),
		'building_id' =>      $retrieve_searched_data[0]['building_id'],
		'company_id' =>       $retrieve_session[0]['company_id']);
		  
		 
		   $result['new_contact'] =  $this->Contactsdata->insertingContact($data);
		if($result['new_contact']==1){
		    $this->session->set_flashdata('Succ', 'Contact Created Successfully!');
			redirect(base_url()."Contacts/listContacts");
		}
		else{
			$this->session->set_flashdata('Err', 'Contact is not Created. Please Check Database Connection!');
	        redirect(base_url()."Contacts/");	 
		}
			  
		
	}
	
    public function listContacts(){
	 
	    $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Contactsdata');  // Load the Model Library..
	   
	   
	      $retrieve_searched_data = $this->session->userdata('search_building_result');
		
		$contact_list['list'] =$this->Contactsdata->allContacts($retrieve_searched_data[0]['building_id']); 
	    $contact_list['call_from'] = "contacts";
	   if($contact_list['list']==0){
		    	 $this->session->set_flashdata('Err', 'No Record Was Found!');
	    }
		
	 
	  $this->load->template('listcontact_information',$contact_list);
	 
	 }
   
    public function updateContact(){
        $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Contactsdata');  // Load the Model Library..
     	
	     $retrieve_searched_data = $this->session->userdata('search_building_result');
	     $retrieve_session = $this->session->userdata('result');
		
		$data = array(
		'contact_name' =>     $this->input->post('c_name'),
		'title' =>            $this->input->post('title'),
		'phone' =>            $this->input->post('phone'),
		'cell' =>             $this->input->post('landline'),
		'email' =>            $this->input->post('email')
		);
		  
		 
		   $result['update_contact'] =  $this->Contactsdata->updateContact($data,$this->input->get('id'));
		if($result['update_contact']){
		    $this->session->set_flashdata('Succ', 'Contact Updated Successfully!');
			redirect(base_url()."Contacts/listContacts");
		}
		else{
			$this->session->set_flashdata('Err', 'Contact is not Created. Please Check Database Connection!');
	        redirect(base_url()."Contacts/");	 
		}
		
	}
	public function update(){
        $this->load->library('session');	  // Load the Session Library..
	    $this->load->model('Contactsdata');  // Load the Model Library..
     	
	   if($this->input->get('id')){
	    $contact_list['id']=$this->input->get('id');
		$contact_list['edit'] =$this->Contactsdata->selectContact($this->input->get('id'));
		if($contact_list['edit']){ 
	      $this->load->template('buildingContacts_information',$contact_list);  
		}
		else{
			$this->session->set_flashdata('Err', 'No Record Found!');
			redirect(base_url()."Contacts/update");
		}
	   }
	   else{
	     
		 redirect(base_url()."Contacts/");
	   }
     	
	}
}
 