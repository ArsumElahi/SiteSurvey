<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authenticate extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	public function checkLogin($useremail,$userpassword)
	{
	
	$this->db->select('surveysite_company_config.company_name as user_name,surveysite_user_config.user_email,
	                   surveysite_user_config.user_password,surveysite_user_config.user_id,surveysite_user_config.user_type,
					   surveysite_company_config.company_name,surveysite_company_config.company_id');
	$this->db->from('surveysite_user_config');
	$this->db->join('surveysite_company_user_detail', 'surveysite_user_config.user_id = surveysite_company_user_detail.user_id');
	$this->db->join('surveysite_company_config', 'surveysite_company_config.company_id = 
	surveysite_company_user_detail.company_id');
	$this->db->where('surveysite_user_config.user_status', 1);
	$this->db->where('surveysite_company_config.company_status', 1);
	$this->db->where('UPPER(surveysite_user_config.user_email)', trim(strtoupper($useremail)));
	$this->db->where('surveysite_user_config.user_password', $userpassword);
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return false;
	}


  public function signUp($data,$company_name){
	 
	    $this->db->set("company_name",$company_name);
		$this->db->set("company_status",1);
		
		$this->db->insert('surveysite_company_config'); 
		$company_id = $this->db->insert_id();
		
		
	    if($this->db->affected_rows() >0){
			$this->db->insert('surveysite_user_config',$data); 
			$user_id = $this->db->insert_id();
			if($this->db->affected_rows() >0){
				 $this->db->set("company_id",$company_id);
	           	 $this->db->set("user_id",$user_id);
				 $this->db->insert('surveysite_company_user_detail'); 
				
				 if($this->db->affected_rows() >0){
				  return true;
				 }
				 else{
				  return false;
				 }
			}
            else{
			  return false;
			}
			
        } else {
            return false;
        }
  }
 public function gettingPermission($user_id){
	  $this->db->select('*');
	  $this->db->from('ss_buildings_permission');
	  $this->db->where('user_id',$user_id);
	 
	  $query = $this->db->get();
	  if ($query->num_rows() > 0){
	   return $query->result_array();	  
	  }
	  return 0;
	 
 }
 public function insertingUser($data,$company_id)
  {
	 
	   $this->db->insert('surveysite_user_config',$data); 
	   $insert_id = $this->db->insert_id();
	  if($this->db->affected_rows() >0){
             $this->db->set('user_id', $insert_id);
	         $this->db->set('company_id', $company_id);
			 $this->db->insert('surveysite_company_user_detail');
			 return $insert_id;
        
	   } else {
            return false;
        }
	  
	   
       
	   
	    
  }
  
   public function insertingPermission($permission,$user_id,$building_id)
  {
	 
	 
	 $this->db->set('user_id', $user_id);
	 $this->db->set('building_id', $building_id);
	 $this->db->set('permission_type', $permission);
	 $this->db->insert('ss_buildings_permission');
	 
	  if($this->db->affected_rows() >0){
             
			 return true;
        
	   } else {
            return false;
        }
	  
	   
       
	   
	    
  }
  
  public function allUser($company_id,$user_id){

    
	$this->db->select('surveysite_user_config.user_name as user_name,surveysite_user_config.user_email,
	                   surveysite_user_config.user_id,surveysite_user_config.user_type,surveysite_user_config.user_status');
	$this->db->from('surveysite_user_config');
	$this->db->join('surveysite_company_user_detail', 'surveysite_user_config.user_id = surveysite_company_user_detail.user_id');
	$this->db->join('surveysite_company_config', 'surveysite_company_config.company_id = 
	surveysite_company_user_detail.company_id');
	$this->db->where('surveysite_company_user_detail.company_id',$company_id);
	$this->db->where('surveysite_user_config.user_id!=', $user_id);
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
	
  
  }
 
public function checkCompanyExist($company_name){
      
	  $this->db->select('*');
	  $this->db->from('surveysite_company_config');
	  $this->db->where('company_name',$company_name);
	  $this->db->where('company_status',1);
	 
	  
	  $query = $this->db->get();
	  if ($query->num_rows() > 0){
	   return $query->result_array();	  
	  }
	  return 0;
	
}
public function checkEmailExist($email){
      
	  $this->db->select('*');
	  $this->db->from('surveysite_user_config');
	  $this->db->where('user_email',$email);
	  $this->db->where('user_status',1);
	 
	  
	  $query = $this->db->get();
	  if ($query->num_rows() > 0){
	   return $query->result_array();	  
	  }
	  return 0;
	
  }
public function building_list($company_id){
	  $this->db->select('building_id,ss_address');
	  $this->db->from('ss_building');
	  $this->db->where('company_id', $company_id);
	  $this->db->where('del_status','0');
	 
	  
	  $query = $this->db->get();
	  
	   if ($query->num_rows() > 0) {
	   return $query->result_array();	  
	  }
	  return false;
 
  }
}
