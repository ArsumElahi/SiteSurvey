<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contactsdata extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	


 public function insertingContact($data){
	 
	   $this->db->insert('ss_contacts',$data); 
	  if($this->db->affected_rows() >0){
           return true;
        
	   } else {
            return false;
        }
	  
	   
       
	   
	    
  }
  
 public function selectContact($id){
	$this->db->select('*');
	$this->db->from('ss_contacts');
	$this->db->where('contacts_id',$id);

	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
}  
 public function updateContact($data,$updation_id){
	 $this->db->where('contacts_id',$updation_id);
	 return  $this->db->update('ss_contacts',$data); 
}
  
  public function allContacts($building_id){

    
	$this->db->select('*');
	$this->db->from('ss_contacts');
	$this->db->where('building_id',$building_id);

	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
	
  
  }
 


}
