<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supportdata extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	
  public function insertingTicketData($user_id,$ticket_id){  
	 
	  $this->db->set('user_id', $user_id);
	  $this->db->set('ticket_id', $ticket_id);
	
	  $this->db->insert("ss_support_detail"); 
  	  
	    if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
 
  }
   public function allTickets($user_id){
	
	$this->db->select('*');
	$this->db->from('ss_support_detail');
	$this->db->where('user_id',$user_id);
	$this->db->order_by("ticket_id", "desc");
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
	
 
 
  }
 
  
  
}
