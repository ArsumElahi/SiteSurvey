<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buildingdata extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	

 public function allBuildings($company_id,$del_status){
	
	$this->db->select('ss_building.*,surveysite_user_config.user_name');
	$this->db->from('ss_building');
	$this->db->where('del_status',$del_status);
	$this->db->where('company_id',$company_id);
	$this->db->join("surveysite_user_config",'ss_building.user_id=surveysite_user_config.user_id');
	$this->db->order_by("ss_building.street", "asc");
	
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
	
 }
 
 public function searchBuildings($keyword ,$company_id){
    $this->db->select('*');
	$this->db->from('ss_building');
	$this->db->where('del_status','0');
	$this->db->where('company_id',$company_id);
	$this->db->where("(street LIKE '%$keyword%' OR city LIKE '%$keyword%' OR state LIKE '%$keyword%'
    OR zip LIKE '%$keyword%')");
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
 
 }
 
 public function trash($building_id){
        $this->db->set('del_status', '1');
		$this->db->where('building_id',$building_id);
		return $this->db->update('ss_building');
 }
 public function restore($building_id){
        $this->db->set('del_status', '0');
		$this->db->where('building_id',$building_id);
		return $this->db->update('ss_building');
 }
 
 
}
