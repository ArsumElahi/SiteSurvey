<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Servicedata extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	
  public function insertingServices($building_id,$type,$value){  
	  $this->db->set('service_type', $type);
	  $this->db->set('service_value', $value);
	  $this->db->set('building_id', $building_id);
	  $this->db->insert("ss_services"); 
  	  $insert_id = $this->db->insert_id();
	    if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
 
  }
   public function deletingServices($building_id,$type,$value){  
	  $this->db->where('service_type', $type);
	  $this->db->where('building_id', $building_id);
	  $this->db->where('service_value', $value);
      $this->db->delete('ss_services');
  	  if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
 
  }
  
  public function checkedServices($building_id){  
	
	
	$this->db->select('*');
	$this->db->from('ss_services');
	$this->db->where('building_id', $building_id);
	 $query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
 
  }
   public function duplicatesServices($lat,$lng,$building_id){  
	
	
	$this->db->select('ss_building.*,surveysite_user_config.user_name');
	$this->db->from('ss_building');
	$this->db->where('latitude', $lat);
	$this->db->where('longitude', $lng);
	$this->db->where('building_id!=', $building_id);
	$this->db->where('ss_building.del_status', "0");
	$this->db->join("surveysite_user_config",'ss_building.user_id=surveysite_user_config.user_id');
	 $query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
 
  }

}
