<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Locationrecordsdata extends CI_Model {
 
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	
  public function insertingBuilding($latitude,$longitude,$address,$company_id,$street,$city,$state,$user_id)
  {
	  $this->db->set('latitude', $latitude);
	  $this->db->set('longitude', $longitude);
	  $this->db->set('ss_address', $address);
	  $this->db->set('company_id', $company_id);
	  $this->db->set('street', $street);
	  $this->db->set('city', $city);
	  $this->db->set('state', $state);
	  $this->db->set('user_id', $user_id);
	  
	  $this->db->insert("ss_building"); 
  	  $insert_id = $this->db->insert_id();
	    if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
 
  }
  public function insertingBuildingDetail($data)
  {
	 
	   $this->db->insert('ss_building_detail',$data); 
	   
	    if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
  }
  
  public function checkBuildingExist($building_id){
      $this->db->select('*');
	  $this->db->from('ss_building_detail');
	  $this->db->where('building_id',$building_id);
	  
	  $query = $this->db->get();
	  if ($query->num_rows() > 0){
	   return $query->result_array();	  
	  }
	  return 0;
	
  }
  
   public function checkLatLng($lat,$lng){
      $this->db->select('building_id,latitude,longitude,ss_address');
	  $this->db->from('ss_building');
	  $this->db->where('latitude',$lat);
	  $this->db->where('longitude',$lng);
	  $this->db->where('del_status','0');
	  
	  $query = $this->db->get();
	  if ($query->num_rows() > 0){
	   return $query->result_array();	  
	  }
	  return 0;
	
  }
  public function allBuilding($company_id){

    
	$this->db->select('surveysite_locarecords_detail.locaRecord_id,surveysite_locarecords_detail.msa_name,
	surveysite_locarecords_detail.building_id,
    surveysite_locarecords_detail.central_office,surveysite_locarecords_detail.building_cat,
    surveysite_locarecords_detail.building_status');
	$this->db->from('surveysite_locarecords_detail');
	$this->db->where('company_id',$company_id);
	
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
  }
  public function edit_BuildingDetail($id){
	  $this->db->select('*');
	  $this->db->from(' surveysite_locarecords_detail');
	  $this->db->where('locaRecord_id', $id);
	
     $query = $this->db->get();
	 
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;	
  }
  
   public function update_BuildingDetail($data,$id){
	  $this->db->where('building_id',$id);
	  $this->db->update('ss_building_detail',$data);
	  
	   if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
  }
 
  public function searchLocation($building_id){
	  $this->db->select('building_id,latitude,longitude,ss_address,surveysite_user_config.user_name');
	  $this->db->from('ss_building');
	  $this->db->where('building_id', $building_id);
	  $this->db->join("surveysite_user_config",'ss_building.user_id=surveysite_user_config.user_id');
	  $this->db->where('del_status','0');
	  
	  $query = $this->db->get();
	  
	   if ($query->num_rows() > 0) {
	   return $query->result_array();	  
	  }
	  return false;
 
  }
	  function giveSuggestion($keyword,$company_id) {
        $this->db->select('*');
		$this->db->from("ss_building");
	    $this->db->where('company_id', $company_id);
		$this->db->where('del_status','0');
		$this->db->where("
		(street LIKE '%$keyword%' OR ss_address LIKE '%$keyword%' OR state LIKE '%$keyword%'
		OR city LIKE '%$keyword%' OR latitude LIKE '%$keyword%' OR longitude LIKE '%$keyword%')");
		
        $query = $this->db->get();
 
        //cek apakah ada data
        if ($query->num_rows() > 0) { //jika ada maka jalankan
            return $query->result();
        }
    }
	 function giveSuggestion_contractor($keyword,$company_id,$user_id) {
        $this->db->select('*');
		$this->db->from("ss_building");
	    $this->db->where('company_id', $company_id);
		$this->db->where('user_id', $user_id);
		$this->db->where('del_status','0');
		$this->db->where("
		(street LIKE '%$keyword%' OR ss_address LIKE '%$keyword%' OR state LIKE '%$keyword%'
		OR city LIKE '%$keyword%' OR latitude LIKE '%$keyword%' OR longitude LIKE '%$keyword%')");
		
        $query = $this->db->get();
 
        //cek apakah ada data
        if ($query->num_rows() > 0) { //jika ada maka jalankan
            return $query->result();
        }
    }
	  function givePermissionSuggestion($keyword,$company_id,$user_id) {
		 
		  $this->db->select('building_id')->from('ss_buildings_permission')->where("user_id",$user_id);
		  $subQuery =  $this->db->get_compiled_select();
        
		$this->db->select('*');
		$this->db->from("ss_building");
		$this->db->where('del_status','0');
	    $this->db->where('company_id', $company_id);
		$this->db->where("building_id IN ($subQuery)", NULL, FALSE);
		$this->db->where("
		(street LIKE '%$keyword%' OR ss_address LIKE '%$keyword%' OR state LIKE '%$keyword%'
		OR city LIKE '%$keyword%' OR latitude LIKE '%$keyword%' OR longitude LIKE '%$keyword%')");
		
        $query = $this->db->get();
 
        //cek apakah ada data
        if ($query->num_rows() > 0) { //jika ada maka jalankan
            return $query->result();
        }
    }
}
