<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attachmentdata extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	
  public function insertingAttachment($data){
	
	  $this->db->insert("ss_attachments",$data); 
  	  
	    if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
 
  }
  
 public function allAttachments($building_id){
	
	$this->db->select('ss_attachments.attachment_path,ss_attachments.attachment_thumbnail,
	ss_attachments.attachment_category,ss_attachments.attachment_name,
	ss_attachments.attachment_link,ss_attachments.capture_date,surveysite_user_config.user_name');
	$this->db->from('ss_attachments');
	$this->db->join('surveysite_user_config', 'surveysite_user_config.user_id = 
	ss_attachments.user_id');
	$this->db->where('ss_attachments.building_id',$building_id);
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
	
 
 
  }
 
  
 
 
}
