<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Picturesdata extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	

  
  public function insertingPictures($building_id,$path,$user_id,$name,$link,$date,$cat_id,$thumb_path){  
	  $this->db->set('building_id', $building_id);
	  $this->db->set('picture_path', $path);
	  $this->db->set('user_id', $user_id);
	  $this->db->set('picture_name', $name);
	  $this->db->set('picture_file_link', $link);
	  $this->db->set('picture_capture_date', $date);
	  $this->db->set('picture_cat_id', $cat_id);
	  $this->db->set('picture_thumbnail_path', $thumb_path);
	  
	  $this->db->insert("ss_pictures"); 
  	  
	    if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
 
  }
 public function allPictures($building_id){
	
	$this->db->select('ss_pictures.*,ss_picture_category.picture_cat_name');
	$this->db->from('ss_pictures');
	$this->db->join('ss_picture_category', 'ss_picture_category.picture_cat_id = 
	ss_pictures.picture_cat_id');
	$this->db->where('ss_pictures.building_id',$building_id);
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
	
 
 
  }  
  public function allCategory(){
	
	$this->db->select('*');
	$this->db->from('ss_picture_category');
	$this->db->where('picture_cat_status',1);
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
	
 
 
  }  
 
  
   

}
