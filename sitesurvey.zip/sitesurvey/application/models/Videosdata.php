<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Videosdata extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
      parent::__construct();
    }
	
  public function insertingVideos($building_id,$path,$user_id,$name,$link,$date,$thumb_path){  
	 
	  $this->db->set('building_id', $building_id);
	  $this->db->set('video_path', $path);
	  $this->db->set('user_id', $user_id);
	  $this->db->set('ss_video_name', $name);
	  $this->db->set('ss_video_file_link', $link);
	  $this->db->set('ss_video_date', $date);
	  $this->db->set('ss_video_thumb_path', $thumb_path);
	  
	  $this->db->insert("ss_videos"); 
  	  
	    if($this->db->affected_rows() >0){
            return true;
        } else {
            return false;
        }
 
  }
   public function allVideos($building_id){
	
	$this->db->select('ss_videos.ss_video_name,ss_videos.video_path,
	ss_videos.ss_video_date,surveysite_user_config.user_name,ss_videos.ss_video_thumb_path');
	$this->db->from('ss_videos');
	$this->db->join('surveysite_user_config', 'surveysite_user_config.user_id = 
	ss_videos.user_id');
	$this->db->where('ss_videos.building_id',$building_id);
	
	$query = $this->db->get();
	  if ($query->num_rows() > 0)
	  {
	   return $query->result_array();	  
	  }
	  return 0;
	
 
 
  }
 
  
  
}
