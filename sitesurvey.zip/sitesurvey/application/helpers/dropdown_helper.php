<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');
 




function listData($table,$name,$value,$status) {
  $items = array();
  $CI =& get_instance();
  
  $query = $CI->db->select("$name,$value")->from($table)->where($status,1)->get();
  if ($query->num_rows() > 0) {
  foreach($query->result() as $data) {
  $items[$data->$name] = $data->$value;
  }
  $query->free_result();
  return $items;
  }
  }




?>